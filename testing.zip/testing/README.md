# Tic-Tac-Toe Mobile Automation

Python and Markdown mobile automation for `com.qatest.xo_qa_challenge`, orchestrated by Strands Agents over LiteLLM Bedrock.

## Setup

```bash
uv sync --extra dev
```

## Run the smoke plan

```bash
uv run testing \
    --test-plan tests/plans/smoke.md \
    --output smoke.md \
    --api-key "$KEY"
```

Set `XO_API_KEY` (or pass `--api-key`), plus `XO_API_BASE` and `XO_MODEL_ID` (or `--api-base` / `--model-id`). Do not commit those values.

The overall report is written to `--output`. Screenshots and a plan copy stay under `reports/<run>/`.

## Parse only

```bash
uv run testing --test-plan tests/plans/smoke.md --dry-run
```

## Tests

```bash
uv run pytest
```

A connected Android device or emulator is required for a live run. The process exits `1` when any task failed or remained pending.

See [ARCHITECTURE.md](ARCHITECTURE.md) for the complete design.
