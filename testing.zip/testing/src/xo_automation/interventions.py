"""Guardrails for the mobile QA orchestrator."""

from strands.hooks.events import BeforeToolCallEvent
from strands.interventions.actions import Deny, Proceed
from strands.interventions.handler import InterventionHandler

from xo_automation.tools.task_manager import structured_plan_has_pending_tasks


class MobileGuardrails(InterventionHandler):
    name = "mobile-qa-guardrails"

    def before_tool_call(self, event: BeforeToolCallEvent, **kwargs):
        name = event.tool_use.get("name", "")
        if name == "finalize_test_plan" and structured_plan_has_pending_tasks():
            return Deny(reason="cannot finalize while tasks remain pending")
        if name == "tap_screen":
            return Deny(
                reason="tap_screen is reserved for calibrated facades; use tap_cell or a selector tool"
            )
        return Proceed()
