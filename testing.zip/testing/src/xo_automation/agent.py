"""Strands Agent construction and bounded Python plan loop."""

from __future__ import annotations

from pathlib import Path

from xo_automation.config import (
    LLM_MAX_RETRIES,
    LLM_REQUEST_TIMEOUT_SECONDS,
    MAX_CONTINUATION_ROUNDS,
    MODEL_API_BASE,
    MODEL_ID,
)
from xo_automation.hooks import ObserveActVerifyHook
from xo_automation.interventions import MobileGuardrails
from xo_automation.models import PlanRunResult, TaskVerdict
from xo_automation.prompts import DEVICE_PROMPT, OBSERVER_PROMPT, ORCHESTRATOR_PROMPT
from xo_automation.runtime import init_session
from xo_automation.step_runner import execute_task
from xo_automation.tools import DEVICE_TOOLS, OBSERVER_TOOLS, ORCHESTRATOR_TOOLS
from xo_automation.tools.storage import record_step, save_report
from xo_automation.tools.task_manager import (
    finalize_test_plan,
    init_test_plan,
    mark_task_complete,
    peek_next_task,
    remaining_pending,
    task_counts,
)

_STRANDS = None


def _load_strands():
    global _STRANDS
    if _STRANDS is None:
        try:
            from strands import Agent
            from strands.models.litellm import LiteLLMModel
            from strands.tools.executors import SequentialToolExecutor
        except ImportError as error:
            raise RuntimeError("Install project dependencies with: uv sync  or  python3 -m pip install -e '.[dev]'") from error
        _STRANDS = (Agent, LiteLLMModel, SequentialToolExecutor)
    return _STRANDS


def _litellm_model_id(model_id: str) -> str:
    if not model_id:
        return ""
    if "/" in model_id:
        return model_id
    return f"litellm_proxy/bedrock/converse/{model_id}"


def build_model(api_key: str, model_id: str | None = None, api_base: str | None = None):
    if not api_key:
        raise RuntimeError("An API key is required for the LiteLLM proxy")
    import logging

    logging.getLogger("LiteLLM").setLevel(logging.WARNING)
    logging.getLogger("litellm").setLevel(logging.WARNING)
    _, LiteLLMModel, _ = _load_strands()
    return LiteLLMModel(
        client_args={
            "api_key": api_key,
            "api_base": api_base or MODEL_API_BASE,
            "max_retries": LLM_MAX_RETRIES,
            "timeout": LLM_REQUEST_TIMEOUT_SECONDS,
        },
        model_id=_litellm_model_id(model_id or MODEL_ID),
    )


def _shared_runtime(api_key: str, model_id: str | None = None, api_base: str | None = None) -> dict:
    _, _, SequentialToolExecutor = _load_strands()
    return {
        "model": build_model(api_key, model_id, api_base),
        "tool_executor": SequentialToolExecutor(),
        "context_manager": "auto",
        "callback_handler": None,
    }


def _agent(*, name: str, description: str, system_prompt: str, tools: list, **extra):
    Agent, _, _ = _load_strands()
    return Agent(name=name, description=description, system_prompt=system_prompt, tools=tools, **extra)


def build_device_agent(runtime: dict):
    return _agent(
        name="device_agent",
        description="Executes low-level Android device operations.",
        system_prompt=DEVICE_PROMPT,
        tools=DEVICE_TOOLS,
        **runtime,
    )


def build_observer_agent(runtime: dict):
    return _agent(
        name="observer_agent",
        description="Summarizes the visible Tic-Tac-Toe board and chrome from UI evidence.",
        system_prompt=OBSERVER_PROMPT,
        tools=OBSERVER_TOOLS,
        **runtime,
    )


def build_agent(api_key: str, model_id: str | None = None, api_base: str | None = None):
    """Build the orchestrator with specialist agents registered as tools."""
    runtime = _shared_runtime(api_key, model_id, api_base)
    device = build_device_agent(runtime)
    observer = build_observer_agent(runtime)
    return _agent(
        name="xo_orchestrator",
        description="Executes one Markdown QA task against the Tic-Tac-Toe app.",
        system_prompt=ORCHESTRATOR_PROMPT,
        tools=[
            *ORCHESTRATOR_TOOLS,
            device.as_tool(name="control_device", description="Recover or inspect the Android device session."),
            observer.as_tool(name="observe_screen", description="Summarize the current board and visible UI."),
        ],
        hooks=[ObserveActVerifyHook()],
        interventions=[MobileGuardrails()],
        structured_output_model=TaskVerdict,
        trace_attributes={"service.name": "xo-mobile-automation", "app.package": "com.qatest.xo_qa_challenge"},
        **runtime,
    )


def run_plan(
    plan_file: str,
    output_dir: str = "reports",
    report_file: str | None = None,
    api_key: str = "",
    model_id: str | None = None,
    api_base: str | None = None,
) -> PlanRunResult:
    path = Path(plan_file).expanduser().resolve()
    context = init_session(path.stem, str(path), output_dir, report_file=report_file)
    loaded = init_test_plan(str(path))
    if loaded.failed():
        saved = save_report(loaded.message)
        return PlanRunResult(
            notes=loaded.message,
            report_path=saved.data.get("path", str(context.run_dir / "overall.md")),
            pending=1,
        )

    exhausted = False
    for _ in range(MAX_CONTINUATION_ROUNDS):
        task = peek_next_task()
        if task is None:
            break
        try:
            status = execute_task(task)
            mark_task_complete(task["name"], status)
        except Exception as error:
            mark_task_complete(task["name"], "failed")
            record_step(
                step_number=len([step for step in context.report.test_steps if step.task_name == task["name"]]) + 1,
                description=task["name"],
                expected_result="Task completes",
                actual_result=str(error),
                status="fail",
                notes="keyword step runner failed",
                task_name=task["name"],
            )
    else:
        exhausted = True

    while remaining_pending():
        leftover = peek_next_task()
        if leftover is None:
            break
        mark_task_complete(leftover["name"], "skipped")

    notes = "continuation rounds exhausted" if exhausted else ""
    finalize_test_plan(notes)
    saved = save_report(notes or "Plan loop completed")
    counts = task_counts()
    return PlanRunResult(
        plan_id=(context.plan_state or {}).get("plan_id", ""),
        report_path=saved.data.get("path", str(context.run_dir / "overall.md")),
        notes=notes,
        **counts,
    )
