"""Runtime configuration for the automation project."""

import os
from pathlib import Path

APP_NAME = "Tic-Tac-Toe"
APP_PACKAGE = os.getenv("XO_APP_PACKAGE", "com.qatest.xo_qa_challenge")
MAX_ACTION_RETRIES = int(os.getenv("XO_MAX_ACTION_RETRIES", "2"))
MAX_CONTINUATION_ROUNDS = int(os.getenv("XO_MAX_CONTINUATION_ROUNDS", "25"))
MAX_TASK_TURNS = int(os.getenv("XO_MAX_TASK_TURNS", "8"))
ADB_TIMEOUT_SECONDS = float(os.getenv("XO_ADB_TIMEOUT", "20"))
DEVICE_SERIAL = os.getenv("XO_DEVICE_ID") or os.getenv("ANDROID_SERIAL") or ""
PROJECT_ROOT = Path(os.getenv("XO_PROJECT_ROOT", os.getcwd())).expanduser().resolve()
MODEL_PROVIDER = os.getenv("XO_MODEL_PROVIDER", "litellm").lower()
MODEL_ID = os.getenv("XO_MODEL_ID", "")
MODEL_API_BASE = os.getenv("XO_API_BASE", "")
LLM_MAX_RETRIES = int(os.getenv("LLM_MAX_RETRIES", "5"))
LLM_REQUEST_TIMEOUT_SECONDS = int(os.getenv("LLM_REQUEST_TIMEOUT_SECONDS", "120"))
BOARD_ORIGIN_X = int(os.getenv("XO_BOARD_ORIGIN_X", "120"))
BOARD_ORIGIN_Y = int(os.getenv("XO_BOARD_ORIGIN_Y", "815"))
BOARD_CELL_SIZE = int(os.getenv("XO_BOARD_CELL_SIZE", "287"))
ADB_BIN = os.getenv("ANDROID_ADB", "adb")
