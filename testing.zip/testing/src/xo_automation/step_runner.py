"""Keyword-driven step execution: Markdown @tool names run in Python."""

from __future__ import annotations

import inspect
from typing import Any

from xo_automation.config import MAX_ACTION_RETRIES
from xo_automation.hooks import MUTATING_TOOLS
from xo_automation.models import BoardObservation, ToolOutcome
from xo_automation.parsers.markdown_plan import MarkdownStep, parse_case, parse_tool_reference
from xo_automation.runtime import current
from xo_automation.tools import (
    assert_board_empty,
    assert_cell_empty,
    assert_cell_mark,
    assert_control_visible,
    assert_current_turn,
    assert_draw,
    assert_reset_state,
    assert_winner,
    background_app,
    check_device_connection,
    get_current_turn,
    get_device_info,
    get_game_status,
    get_screen_elements,
    play_moves,
    reset_game,
    resume_app,
    start_new_game,
    take_screenshot,
    tap_cell,
    wait_for_game_state,
)
from xo_automation.tools.results import failed, is_failure
from xo_automation.tools.storage import record_step
from xo_automation.tools.ui import try_capture_observation


STEP_REGISTRY: dict[str, Any] = {
    "check_device_connection": check_device_connection,
    "get_device_info": get_device_info,
    "get_screen_elements": get_screen_elements,
    "start_new_game": start_new_game,
    "reset_game": reset_game,
    "tap_cell": tap_cell,
    "play_moves": play_moves,
    "wait_for_game_state": wait_for_game_state,
    "background_app": background_app,
    "resume_app": resume_app,
    "assert_cell_mark": assert_cell_mark,
    "assert_cell_empty": assert_cell_empty,
    "assert_board_empty": assert_board_empty,
    "assert_current_turn": assert_current_turn,
    "assert_control_visible": assert_control_visible,
    "assert_winner": assert_winner,
    "assert_draw": assert_draw,
    "assert_reset_state": assert_reset_state,
    "get_current_turn": get_current_turn,
    "get_game_status": get_game_status,
    "take_screenshot": take_screenshot,
}


def _unwrap_tool(entry: Any):
    for attr in ("_func", "func", "__wrapped__"):
        candidate = getattr(entry, attr, None)
        if callable(candidate) and candidate is not entry:
            return candidate
    unwrapped = inspect.unwrap(entry)
    return unwrapped if callable(unwrapped) else entry


def invoke_named_tool(name: str, arguments: dict[str, Any] | None = None) -> ToolOutcome:
    entry = STEP_REGISTRY.get(name)
    if entry is None:
        return failed(f"unknown tool: {name}")
    try:
        result = _unwrap_tool(entry)(**(arguments or {}))
    except TypeError:
        result = entry(**(arguments or {}))
    except Exception as error:
        return failed(str(error))
    if isinstance(result, ToolOutcome):
        return result
    return failed(f"{name} returned an unstructured result")


def _observe_before(tool_name: str) -> ToolOutcome | None:
    if tool_name not in MUTATING_TOOLS:
        return None
    observed = try_capture_observation("observe_before")
    if isinstance(observed, ToolOutcome) and observed.failed():
        return observed
    context = current()
    if context and isinstance(observed, BoardObservation):
        context.observed_since_mutation = True
    return None


def _invoke_with_retries(name: str, arguments: dict[str, Any]) -> ToolOutcome:
    attempts = 1 + (MAX_ACTION_RETRIES if name in MUTATING_TOOLS else 0)
    last = failed(f"{name} did not run")
    for _ in range(attempts):
        last = invoke_named_tool(name, arguments)
        if not is_failure(last):
            return last
    return last


def steps_for_task(task: dict) -> list[MarkdownStep]:
    if task.get("type") == "test_case" and task.get("resolved_path"):
        return list(parse_case(task["resolved_path"]).steps)
    name, arguments = parse_tool_reference(task["ref"])
    return [
        MarkdownStep(
            number=1,
            title=task["name"],
            action=task["name"],
            tool_name=name,
            tool_arguments="",
            parsed_arguments=arguments,
            expected_result="The referenced tool completes successfully",
        )
    ]


def execute_step(step: MarkdownStep, task_name: str) -> ToolOutcome:
    """Observe before a mutation, run the keyword tool, then record the verdict."""
    blocked = _observe_before(step.tool_name)
    if blocked is not None:
        record_step(
            step_number=step.number,
            description=step.title,
            expected_result=step.expected_result,
            actual_result=blocked.message,
            status="fail",
            notes="observe-act-verify: UI could not be observed before the action",
            evidence=",".join(blocked.evidence),
            task_name=task_name,
        )
        return blocked
    outcome = _invoke_with_retries(step.tool_name, step.parsed_arguments)
    record_step(
        step_number=step.number,
        description=step.title,
        expected_result=step.expected_result,
        actual_result=outcome.message,
        status="fail" if outcome.failed() else "pass",
        notes="",
        evidence=",".join(outcome.evidence),
        task_name=task_name,
    )
    return outcome


def execute_task(task: dict) -> str:
    """Run every prescribed Markdown step and return completed or failed."""
    failed_any = False
    for step in steps_for_task(task):
        outcome = execute_step(step, task["name"])
        if outcome.failed():
            failed_any = True
    return "failed" if failed_any else "completed"
