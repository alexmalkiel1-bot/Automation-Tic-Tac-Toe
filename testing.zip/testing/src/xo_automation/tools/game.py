"""Tic-Tac-Toe-specific composite mobile flows."""

from __future__ import annotations

import time

from xo_automation.config import APP_PACKAGE, BOARD_CELL_SIZE, BOARD_ORIGIN_X, BOARD_ORIGIN_Y
from xo_automation.models import BoardObservation, ToolOutcome
from xo_automation.runtime import current
from xo_automation.tools.compat import tool
from xo_automation.tools.mobile import adb, launch_app, stop_app, tap_at, tap_element_by_description
from xo_automation.tools.results import failed, is_failure, passed
from xo_automation.tools.ui import is_valid_cell, try_capture_observation


def _snapshot(data: BoardObservation | dict | None) -> tuple | None:
    if data is None:
        return None
    payload = data.model_dump() if isinstance(data, BoardObservation) else data
    return (
        tuple(tuple(row) for row in payload.get("board", [])),
        payload.get("current_turn", ""),
        payload.get("game_status", ""),
        payload.get("positions_logged"),
    )


def _before_tap_snapshot() -> dict | None:
    context = current()
    if context and context.last_observation:
        return context.last_observation
    observed = try_capture_observation("observe_before")
    if isinstance(observed, BoardObservation):
        return observed.model_dump()
    return None


def _observe_after(label: str) -> ToolOutcome:
    observed = try_capture_observation(label, screenshot=True)
    if isinstance(observed, ToolOutcome):
        return observed
    return passed(
        f"{label}: board observed with {observed.visible_cells} labeled cells",
        data=observed.model_dump(),
        evidence=observed.evidence,
    )


@tool
def start_new_game() -> ToolOutcome:
    """Stop and relaunch the Tic-Tac-Toe app, then observe the resulting board."""
    stopped = stop_app(APP_PACKAGE)
    if is_failure(stopped):
        return stopped
    launched = launch_app(APP_PACKAGE)
    if is_failure(launched):
        return launched
    time.sleep(0.8)
    return _observe_after("start_new_game")


@tool
def reset_game() -> ToolOutcome:
    """Activate the visible reset control and observe the resulting board."""
    result = tap_element_by_description("Reset Game")
    if is_failure(result):
        return result
    time.sleep(0.4)
    return _observe_after("reset_game")


@tool
def tap_cell(row: int, column: int, expect_change: bool = True) -> ToolOutcome:
    """Tap one board cell, then verify the visible game state against the expected change.

    Args:
        row: Zero-based board row (0-2).
        column: Zero-based board column (0-2).
        expect_change: When true, the tap must change board, turn, status, or move count.
            When false, the tap must leave that visible state unchanged.
    """
    if not is_valid_cell(row, column):
        return failed("row and column must each be between 0 and 2")
    before = _before_tap_snapshot()
    x = BOARD_ORIGIN_X + column * BOARD_CELL_SIZE + BOARD_CELL_SIZE // 2
    y = BOARD_ORIGIN_Y + row * BOARD_CELL_SIZE + BOARD_CELL_SIZE // 2
    try:
        tap_at(x, y)
    except RuntimeError as error:
        return failed(str(error))
    time.sleep(0.3)
    observed = _observe_after(f"tap_cell_{row}_{column}")
    if observed.failed():
        return observed
    observed.data = {**observed.data, "row": row, "column": column, "x": x, "y": y, "expect_change": expect_change}
    changed = _snapshot(before) != _snapshot(observed.data) if before is not None else expect_change
    if expect_change and not changed:
        return failed(
            f"tapped cell ({row},{column}) but the visible game state did not change",
            data=observed.data,
            evidence=observed.evidence,
        )
    if not expect_change and changed:
        return failed(
            f"tapped cell ({row},{column}) and the visible game state changed; expected the tap to be ignored",
            data=observed.data,
            evidence=observed.evidence,
        )
    if expect_change:
        observed.message = f"tapped cell ({row},{column}); {observed.message}"
    else:
        observed.message = f"tapped cell ({row},{column}); visible game state was unchanged"
    return observed


@tool
def play_moves(moves: str) -> ToolOutcome:
    """Play a prescribed sequence of cells. Each move is observed individually.

    Args:
        moves: Semicolon-separated row,column pairs such as '1,1; 0,0; 2,2'.
    """
    cells: list[tuple[int, int]] = []
    for part in [item.strip() for item in moves.replace("|", ";").split(";") if item.strip()]:
        bits = [bit.strip() for bit in part.split(",")]
        if len(bits) != 2 or not all(bit.isdigit() for bit in bits):
            return failed(f"invalid move '{part}'; expected row,column")
        cells.append((int(bits[0]), int(bits[1])))
    if not cells:
        return failed("moves must contain at least one row,column pair")
    last = None
    for row, column in cells:
        last = tap_cell(row, column)
        if is_failure(last):
            return last
    return last or failed("no moves executed")


@tool
def background_app() -> ToolOutcome:
    """Send the current app to the background with the Home key."""
    result = adb("shell", "input", "keyevent", "3")
    if result.returncode != 0:
        return failed((result.stderr or "failed to press Home").strip())
    time.sleep(0.4)
    return passed("app sent to background")


@tool
def resume_app() -> ToolOutcome:
    """Bring the Tic-Tac-Toe app back to the foreground without force-stopping it."""
    launched = launch_app(APP_PACKAGE)
    if is_failure(launched):
        return launched
    time.sleep(0.5)
    return _observe_after("resume_app")


@tool
def wait_for_game_state(state: str, timeout_seconds: float = 5.0) -> ToolOutcome:
    """Poll the visible UI until the requested game status is observed or the timeout expires.

    Args:
        state: Expected status: playing, won, draw, or unknown.
        timeout_seconds: How long to poll before failing.
    """
    allowed = {"playing", "won", "draw", "unknown"}
    if state not in allowed:
        return failed(f"unsupported game state {state}; expected one of {sorted(allowed)}")
    deadline = time.time() + max(0.2, timeout_seconds)
    last = None
    while time.time() <= deadline:
        last = _observe_after("wait_for_game_state")
        if last.failed():
            return last
        if last.data.get("game_status") == state:
            return passed(f"observed game state '{state}'", data=last.data, evidence=last.evidence)
        time.sleep(0.4)
    return failed(
        f"timed out waiting for game state '{state}'",
        data=last.data if last else {},
        evidence=last.evidence if last else [],
    )
