"""Markdown-only report repository."""

from datetime import datetime, timezone
from pathlib import Path

from xo_automation.models import TestReport, TestStepResult, ToolOutcome
from xo_automation.runtime import current, init_session as start_session, utc_now
from xo_automation.tools.compat import tool
from xo_automation.tools.results import failed, passed


def init_session(
    plan_name: str = "",
    plan_path: str = "",
    output_dir: str = "reports",
    report_file: str | None = None,
) -> Path:
    return start_session(plan_name, plan_path, output_dir, report_file=report_file).run_dir


def get_report() -> TestReport | None:
    context = current()
    return context.report if context else None


def _task_order() -> dict[str, int]:
    context = current()
    tasks = ((context.plan_state or {}).get("tasks") if context else None) or []
    return {task["name"]: index for index, task in enumerate(tasks)}


def _sorted_steps(report: TestReport) -> list[TestStepResult]:
    order = _task_order()
    return sorted(
        report.test_steps,
        key=lambda step: (order.get(step.task_name, len(order)), step.task_name, step.step_number, step.timestamp),
    )


def _markdown_report(report: TestReport) -> str:
    lines = [
        f"# Test Report: {report.test_plan_name or 'Tic-Tac-Toe Run'}",
        "",
        f"**App:** {report.app_name} (`{report.app_package}`)",
        f"**Device:** {report.device_id or 'unknown'}",
        f"**Source plan:** {report.test_plan_path}",
        f"**Started:** {report.start_time}",
        f"**Ended:** {report.end_time}",
        "",
        "## Summary",
        report.summary or "No summary provided.",
        "",
        f"- Total steps: {report.total_steps}",
        f"- Passed: {report.passed_steps}",
        f"- Failed: {report.failed_steps}",
        f"- Skipped: {report.skipped_steps}",
        "",
        "## Test Steps",
        "",
    ]
    current_task = None
    for step in _sorted_steps(report):
        task_name = step.task_name or "Unscoped"
        if task_name != current_task:
            current_task = task_name
            lines.extend([f"### {task_name}", ""])
        lines.extend(
            [
                f"#### Step {step.step_number}: {step.description}",
                "",
                "| Field | Value |",
                "|---|---|",
                f"| Expected | {step.expected_result} |",
                f"| Actual | {step.actual_result} |",
                f"| Status | {step.status.upper()} |",
                f"| Timestamp | {step.timestamp} |",
                f"| Notes | {step.notes or 'None'} |",
                f"| Evidence | {', '.join(step.evidence) or 'None'} |",
                "",
            ]
        )
    return "\n".join(lines)


@tool
def record_step(
    step_number: int,
    description: str,
    expected_result: str,
    actual_result: str,
    status: str,
    notes: str = "",
    evidence: str = "",
    task_name: str = "",
) -> ToolOutcome:
    """Record one step verdict into the current Markdown report.

    Args:
        step_number: 1-based step number within the current task.
        description: What the step did.
        expected_result: Expected observable result.
        actual_result: What was actually observed.
        status: pass, fail, or skipped.
        notes: Optional notes about retries or UI friction.
        evidence: Optional comma-separated evidence paths.
        task_name: Plan task that owns this step. Defaults to the current task.
    """
    context = current()
    if context is None:
        return failed("report session is not initialized")
    if status not in {"pass", "fail", "skipped", "pending"}:
        return failed("status must be pass, fail, skipped, or pending")
    owner = (task_name or context.current_task_name or "").strip()
    paths = [item.strip() for item in evidence.split(",") if item.strip()]
    step = TestStepResult(
        task_name=owner,
        step_number=step_number,
        description=description,
        expected_result=expected_result,
        actual_result=actual_result,
        status=status,
        timestamp=utc_now(),
        notes=notes,
        evidence=paths,
    )
    context.report.test_steps = [
        existing
        for existing in context.report.test_steps
        if (existing.task_name, existing.step_number) != (step.task_name, step.step_number)
    ]
    context.report.test_steps.append(step)
    context.report.test_steps = _sorted_steps(context.report)
    return passed(f"Recorded {owner or 'task'} step {step.step_number}: {step.status}")


@tool
def save_report(summary: str = "") -> ToolOutcome:
    """Write the overall Markdown report for the current run.

    Args:
        summary: Human-readable run summary.
    """
    context = current()
    if context is None:
        return failed("report session is not initialized")
    context.report.end_time = datetime.now(timezone.utc).isoformat()
    if summary:
        context.report.summary = summary
    markdown = _markdown_report(context.report)
    archive = context.run_dir / "overall.md"
    archive.write_text(markdown, encoding="utf-8")
    output = context.report_file or archive
    if context.report_file:
        context.report_file.parent.mkdir(parents=True, exist_ok=True)
        context.report_file.write_text(markdown, encoding="utf-8")
    return passed(f"Markdown report saved to {output}", data={"path": str(output)})
