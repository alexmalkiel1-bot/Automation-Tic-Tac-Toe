"""Android adapter boundary used by the agent tools."""

from __future__ import annotations

import subprocess
from pathlib import Path
from xml.etree import ElementTree

from xo_automation.config import ADB_BIN, ADB_TIMEOUT_SECONDS, DEVICE_SERIAL
from xo_automation.runtime import current, ensure_under_root, utc_now
from xo_automation.tools.compat import tool
from xo_automation.tools.results import failed, passed
from xo_automation.tools.ui import bounds_center, extract_ui_xml, parse_bounds, try_capture_observation
from xo_automation.models import ToolOutcome


def adb(*args: str, binary: bool = False, timeout: float | None = None) -> subprocess.CompletedProcess:
    command = [ADB_BIN]
    if DEVICE_SERIAL:
        command.extend(["-s", DEVICE_SERIAL])
    command.extend(args)
    return subprocess.run(
        command,
        capture_output=True,
        text=not binary,
        check=False,
        timeout=timeout or ADB_TIMEOUT_SECONDS,
    )


def dump_ui_xml() -> str:
    dump = adb("exec-out", "uiautomator", "dump", "/dev/tty")
    xml = extract_ui_xml(dump.stdout or "")
    if xml.startswith("<?xml") or xml.startswith("<hierarchy"):
        return xml
    fallback = adb("shell", "uiautomator", "dump", "/sdcard/window.xml")
    if fallback.returncode != 0:
        raise RuntimeError((fallback.stderr or dump.stderr or "uiautomator dump failed").strip())
    result = adb("shell", "cat", "/sdcard/window.xml")
    cleaned = extract_ui_xml(result.stdout or "")
    if result.returncode != 0 or not cleaned:
        raise RuntimeError((result.stderr or "unable to read UI dump").strip())
    return cleaned


def tap_at(x: int, y: int) -> None:
    result = adb("shell", "input", "tap", str(x), str(y))
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "tap failed").strip())


def capture_png() -> bytes:
    result = adb("exec-out", "screencap", "-p", binary=True)
    if result.returncode != 0 or not result.stdout:
        raise RuntimeError((result.stderr or b"screenshot failed").decode(errors="ignore").strip())
    return result.stdout


def save_screenshot(label: str = "screen") -> Path:
    context = current()
    directory = context.evidence_dir if context else Path("reports") / "evidence"
    directory.mkdir(parents=True, exist_ok=True)
    stamp = utc_now().replace(":", "").replace("-", "")
    path = directory / f"{label}-{stamp}.png"
    if context:
        path = ensure_under_root(path, context.run_dir)
    path.write_bytes(capture_png())
    return path


def _tap_matching_element(attribute: str, value: str, index: int) -> ToolOutcome:
    if index < 0:
        return failed("index must be non-negative")
    try:
        xml = dump_ui_xml()
        nodes = [node for node in ElementTree.fromstring(xml).iter() if node.attrib.get(attribute) == value]
    except (RuntimeError, ElementTree.ParseError) as error:
        return failed(str(error))
    if len(nodes) <= index:
        return failed(f"{attribute} element not found: {value}")
    bounds = parse_bounds(nodes[index].attrib.get("bounds", ""))
    if bounds is None:
        return failed(f"element has no usable bounds: {value}")
    x, y = bounds_center(bounds)
    try:
        tap_at(x, y)
    except RuntimeError as error:
        return failed(str(error))
    return passed(f"tapped {attribute}={value}", data={"x": x, "y": y})


@tool
def check_device_connection() -> ToolOutcome:
    """Check whether an Android device or emulator is connected and ready.

    Returns:
        Pass when adb reports a ready device; fail otherwise.
    """
    try:
        result = adb("get-state")
    except (OSError, subprocess.TimeoutExpired) as error:
        return failed(f"adb is not usable: {error}")
    if result.returncode == 0 and (result.stdout or "").strip() == "device":
        return passed("Android device is connected")
    return failed(f"no ready Android device ({(result.stderr or result.stdout or '').strip()})")


@tool
def get_device_info() -> ToolOutcome:
    """Read the connected device serial and model."""
    try:
        model = adb("shell", "getprop", "ro.product.model")
        serial = adb("get-serialno")
    except (OSError, subprocess.TimeoutExpired) as error:
        return failed(str(error))
    if model.returncode != 0:
        return failed((model.stderr or "").strip())
    device_id = (serial.stdout or "").strip()
    context = current()
    if context:
        context.report.device_id = device_id
    return passed(
        f"device_id={device_id}, model={(model.stdout or '').strip()}",
        data={"device_id": device_id, "model": (model.stdout or "").strip()},
    )


@tool
def is_app_installed(package_name: str) -> ToolOutcome:
    """Check whether a package is installed on the device.

    Args:
        package_name: Android application package identifier.
    """
    result = adb("shell", "pm", "path", package_name)
    if result.returncode == 0 and (result.stdout or "").strip():
        return passed(f"{package_name} is installed")
    return failed(f"{package_name} is not installed")


@tool
def launch_app(package_name: str) -> ToolOutcome:
    """Launch an installed Android app through the MAIN/LAUNCHER intent.

    Args:
        package_name: Android application package identifier.
    """
    result = adb(
        "shell",
        "am",
        "start",
        "-a",
        "android.intent.action.MAIN",
        "-c",
        "android.intent.category.LAUNCHER",
        package_name,
    )
    if result.returncode != 0:
        fallback = adb("shell", "monkey", "-p", package_name, "-c", "android.intent.category.LAUNCHER", "1")
        if fallback.returncode != 0:
            return failed((fallback.stderr or result.stderr or "launch failed").strip())
    return passed(f"launched {package_name}")


@tool
def stop_app(package_name: str) -> ToolOutcome:
    """Force-stop an Android app.

    Args:
        package_name: Android application package identifier.
    """
    result = adb("shell", "am", "force-stop", package_name)
    if result.returncode != 0:
        return failed((result.stderr or "").strip())
    return passed(f"stopped {package_name}")


@tool
def get_screen_elements() -> ToolOutcome:
    """Observe the current UI as a compact accessibility summary. Does not return raw XML."""
    observed = try_capture_observation("screen")
    if isinstance(observed, ToolOutcome):
        return observed
    return passed("screen observed", data=observed.model_dump(), evidence=observed.evidence)


@tool
def tap_screen(x: int, y: int) -> ToolOutcome:
    """Tap an absolute screen coordinate. Prefer a text, id, or description selector.

    Args:
        x: Horizontal pixel coordinate.
        y: Vertical pixel coordinate.
    """
    try:
        tap_at(x, y)
    except RuntimeError as error:
        return failed(str(error))
    return passed("tap executed", data={"x": x, "y": y})


@tool
def tap_element_by_text(text: str, index: int = 0) -> ToolOutcome:
    """Tap a visible node by its text attribute.

    Args:
        text: Exact text of the target node.
        index: Zero-based match index when several nodes share the text.
    """
    return _tap_matching_element("text", text, index)


@tool
def tap_element_by_id(resource_id: str, index: int = 0) -> ToolOutcome:
    """Tap a visible node by resource-id.

    Args:
        resource_id: Full or short Android resource id.
        index: Zero-based match index when several nodes share the id.
    """
    return _tap_matching_element("resource-id", resource_id, index)


@tool
def tap_element_by_description(description: str, index: int = 0) -> ToolOutcome:
    """Tap a visible node by content-desc.

    Args:
        description: Exact content description.
        index: Zero-based match index when several nodes share the description.
    """
    return _tap_matching_element("content-desc", description, index)


@tool
def press_back() -> ToolOutcome:
    """Press the Android back key."""
    result = adb("shell", "input", "keyevent", "4")
    if result.returncode != 0:
        return failed((result.stderr or "").strip())
    return passed("back pressed")


@tool
def take_screenshot(output_path: str = "") -> ToolOutcome:
    """Capture a PNG screenshot into the current run evidence directory.

    Args:
        output_path: Optional destination path. Must stay under the project or run directory.
    """
    try:
        if output_path:
            path = Path(output_path)
            context = current()
            path = ensure_under_root(path, context.run_dir if context else None)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(capture_png())
        else:
            path = save_screenshot("screen")
    except (OSError, RuntimeError, ValueError) as error:
        return failed(str(error))
    return passed(f"screenshot saved to {path}", evidence=[str(path)])
