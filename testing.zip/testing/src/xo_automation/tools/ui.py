"""Observe the Tic-Tac-Toe UI without reimplementing game rules."""

from __future__ import annotations

import re
from xml.etree import ElementTree

from xo_automation.config import BOARD_CELL_SIZE, BOARD_ORIGIN_X, BOARD_ORIGIN_Y
from xo_automation.models import BoardObservation, CellMark, GameStatus

_BOUNDS_RE = re.compile(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]")
_TURN_RE = re.compile(r"Player ([XO])'s turn \(([XO])\)", re.I)
_CELL_RE = re.compile(
    r"(?:cell|square|tile)[^\d]*([0-2])[^\d]+([0-2])|row[^\d]*([0-2]).*col(?:umn)?[^\d]*([0-2])",
    re.I,
)
_ID_CELL_RE = re.compile(r"(?:cell|tile|square)[_/-]?([0-2])[_/-]?([0-2])", re.I)
_MARK_RE = re.compile(r"\b([XO])\b")
_EMPTY_RE = re.compile(r"\b(empty|blank|none|unmarked)\b", re.I)
_CHROME_RE = re.compile(
    r"player [xo0]'s turn|reset game|restart|session:|\bversus\b|\bvs\b|player [xo0] name",
    re.I,
)
_POSITIONS_RE = re.compile(r"(\d+)\s+positions?\s+logged", re.I)


def is_valid_cell(row: int, column: int) -> bool:
    return row in range(3) and column in range(3)


def extract_ui_xml(raw: str) -> str:
    """Return the UIAutomator document, dropping adb dump trailers after </hierarchy>."""
    text = raw or ""
    start = text.find("<?xml")
    if start == -1:
        start = text.find("<hierarchy")
    if start == -1:
        return text.strip()
    end = text.rfind("</hierarchy>")
    if end == -1:
        return text[start:].strip()
    return text[start : end + len("</hierarchy>")].strip()


def parse_bounds(raw: str) -> tuple[int, int, int, int] | None:
    match = _BOUNDS_RE.fullmatch(raw or "")
    if not match:
        return None
    return tuple(int(part) for part in match.groups())


def bounds_center(bounds: tuple[int, int, int, int]) -> tuple[int, int]:
    left, top, right, bottom = bounds
    return (left + right) // 2, (top + bottom) // 2


def cell_from_bounds(
    bounds: tuple[int, int, int, int],
    origin_x: int = BOARD_ORIGIN_X,
    origin_y: int = BOARD_ORIGIN_Y,
    cell_size: int = BOARD_CELL_SIZE,
) -> tuple[int, int] | None:
    if cell_size <= 0:
        return None
    x, y = bounds_center(bounds)
    column = (x - origin_x) // cell_size
    row = (y - origin_y) // cell_size
    if is_valid_cell(int(row), int(column)):
        return int(row), int(column)
    return None


def _extract_coords(desc: str, resource_id: str) -> tuple[int, int] | None:
    match = _CELL_RE.search(desc)
    if match:
        row = match.group(1) or match.group(3)
        column = match.group(2) or match.group(4)
        return int(row), int(column)
    match = _ID_CELL_RE.search(resource_id.rsplit("/", 1)[-1])
    if match:
        return int(match.group(1)), int(match.group(2))
    return None


def _extract_mark(desc: str, text: str) -> CellMark | None:
    blob = f"{desc} {text}".strip()
    if not blob:
        return None
    if _EMPTY_RE.search(blob):
        return ""
    marks = _MARK_RE.findall(blob)
    if len(set(marks)) == 1:
        return marks[0]  # type: ignore[return-value]
    return None


def _is_chrome(desc: str, text: str) -> bool:
    blob = f"{desc} {text}".strip()
    if not blob:
        return False
    if _CELL_RE.search(desc) or _ID_CELL_RE.search(desc):
        return False
    return _CHROME_RE.search(blob) is not None


def _is_cell_sized(bounds: tuple[int, int, int, int]) -> bool:
    width = bounds[2] - bounds[0]
    height = bounds[3] - bounds[1]
    if width < 60 or height < 60 or width > 600 or height > 600:
        return False
    return 0.7 <= width / height <= 1.4


def _grid_from_bounds(candidates: list[tuple[tuple[int, int, int, int], CellMark]]) -> dict[tuple[int, int], CellMark] | None:
    """Map nine similar-sized squares onto a 3x3 from their on-screen positions."""
    if len(candidates) < 9:
        return None
    widths = sorted(bounds[2] - bounds[0] for bounds, _ in candidates)
    median = widths[len(widths) // 2]
    similar = [
        item for item in candidates if abs((item[0][2] - item[0][0]) - median) <= max(20, median * 0.25)
    ]
    if len(similar) < 9:
        similar = list(candidates)
    if len(similar) > 9:
        cx = sum(bounds_center(bounds)[0] for bounds, _ in similar) / len(similar)
        cy = sum(bounds_center(bounds)[1] for bounds, _ in similar) / len(similar)
        similar = sorted(
            similar,
            key=lambda item: (bounds_center(item[0])[0] - cx) ** 2 + (bounds_center(item[0])[1] - cy) ** 2,
        )[:9]
    if len(similar) != 9:
        return None
    similar.sort(key=lambda item: (bounds_center(item[0])[1], bounds_center(item[0])[0]))
    return {divmod(index, 3): mark for index, (_bounds, mark) in enumerate(similar)}


def compact_ui_summary(xml: str, limit: int = 40) -> str:
    try:
        root = ElementTree.fromstring(extract_ui_xml(xml))
    except ElementTree.ParseError as error:
        return f"invalid UIAutomator XML: {error}"
    lines: list[str] = []
    for node in root.iter():
        text = node.attrib.get("text", "").strip()
        desc = node.attrib.get("content-desc", "").strip()
        resource_id = node.attrib.get("resource-id", "").strip()
        clickable = node.attrib.get("clickable") == "true"
        if not (text or desc or (clickable and resource_id)):
            continue
        parts = []
        if desc:
            parts.append(f"desc={desc}")
        if text:
            parts.append(f"text={text}")
        if resource_id:
            parts.append(f"id={resource_id}")
        if clickable:
            parts.append("clickable")
        lines.append(" | ".join(parts))
        if len(lines) >= limit:
            break
    return "\n".join(lines) if lines else "no labeled or clickable nodes"


def observe_board(xml: str) -> BoardObservation:
    board: list[list[CellMark]] = [["", "", ""] for _ in range(3)]
    visible = 0
    current_turn = ""
    status: GameStatus = "playing"
    document = extract_ui_xml(xml)
    try:
        root = ElementTree.fromstring(document)
    except ElementTree.ParseError as error:
        return BoardObservation(
            game_status="unknown",
            parse_ok=False,
            summary=f"invalid UIAutomator XML: {error}",
        )

    haystack = document
    turn = _TURN_RE.search(haystack)
    if turn:
        current_turn = turn.group(2)
    lowered = haystack.lower()
    if "draw" in lowered or "tie" in lowered:
        status = "draw"
    elif "winner" in lowered or "wins" in lowered or "won" in lowered:
        status = "won"
    elif not current_turn:
        status = "unknown"

    labeled: set[tuple[int, int]] = set()
    grid_nodes: list[tuple[tuple[int, int, int, int], CellMark]] = []
    for node in root.iter():
        desc = node.attrib.get("content-desc", "")
        text = node.attrib.get("text", "")
        resource_id = node.attrib.get("resource-id", "")
        bounds = parse_bounds(node.attrib.get("bounds", ""))
        clickable = node.attrib.get("clickable") == "true"
        coords = _extract_coords(desc, resource_id)
        mark = _extract_mark(desc, text)
        if coords is not None and is_valid_cell(*coords):
            board[coords[0]][coords[1]] = mark if mark is not None else ""
            labeled.add(coords)
            visible += 1
            continue
        if _is_chrome(desc, text) or bounds is None or not _is_cell_sized(bounds):
            continue
        if clickable or mark is not None:
            grid_nodes.append((bounds, mark if mark is not None else ""))

    discovered = _grid_from_bounds(grid_nodes)
    if discovered:
        for (row, column), mark in discovered.items():
            if (row, column) in labeled:
                continue
            board[row][column] = mark
            visible += 1
    else:
        for bounds, mark in grid_nodes:
            coords = cell_from_bounds(bounds)
            if coords is None or coords in labeled:
                continue
            board[coords[0]][coords[1]] = mark
            labeled.add(coords)
            visible += 1

    positions = _POSITIONS_RE.search(haystack)
    return BoardObservation(
        board=board,
        current_turn=current_turn,
        game_status=status,
        visible_cells=visible,
        parse_ok=True,
        positions_logged=int(positions.group(1)) if positions else None,
        summary=compact_ui_summary(document),
    )


def capture_observation(label: str = "observe", screenshot: bool = False) -> BoardObservation:
    """Dump the UI, parse the board, and record the observation on the run context."""
    from xo_automation.runtime import current
    from xo_automation.tools.mobile import dump_ui_xml, save_screenshot

    observation = observe_board(dump_ui_xml())
    if screenshot:
        try:
            observation.evidence = [str(save_screenshot(label))]
        except RuntimeError:
            observation.evidence = []
    context = current()
    if context:
        context.last_observation = observation.model_dump()
        context.observed_since_mutation = True
    return observation


def try_capture_observation(label: str = "observe", screenshot: bool = False):
    from xo_automation.tools.results import failed

    try:
        return capture_observation(label, screenshot=screenshot)
    except RuntimeError as error:
        return failed(str(error))
