"""Helpers for structured tool results."""

from typing import Any

from xo_automation.models import ToolOutcome


def outcome(
    status: str,
    message: str,
    data: dict[str, Any] | None = None,
    evidence: list[str] | None = None,
) -> ToolOutcome:
    return ToolOutcome(status=status, message=message, data=data or {}, evidence=evidence or [])


def passed(message: str, data: dict[str, Any] | None = None, evidence: list[str] | None = None) -> ToolOutcome:
    return outcome("pass", message, data, evidence)


def failed(message: str, data: dict[str, Any] | None = None, evidence: list[str] | None = None) -> ToolOutcome:
    return outcome("fail", message, data, evidence)


def is_failure(result: Any) -> bool:
    if isinstance(result, ToolOutcome):
        return result.failed()
    if isinstance(result, dict):
        if result.get("status") in {"error", "fail"}:
            return True
        for block in result.get("content") or []:
            text = str(block.get("text", "")) if isinstance(block, dict) else ""
            if '"status": "fail"' in text or text.lower().startswith("fail"):
                return True
        return False
    return str(result).lower().startswith("fail")
