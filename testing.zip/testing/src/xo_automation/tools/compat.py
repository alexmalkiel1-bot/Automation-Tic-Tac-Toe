"""Small compatibility boundary for Strands tool decoration."""

try:
    from strands import tool as strands_tool
except ImportError:
    def strands_tool(function):
        return function


tool = strands_tool
