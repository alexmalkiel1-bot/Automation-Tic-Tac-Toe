"""Assertions based on the app's observable UI, not a shadow game engine."""

from xo_automation.models import BoardObservation, ToolOutcome
from xo_automation.tools.compat import tool
from xo_automation.tools.results import failed, passed
from xo_automation.tools.ui import is_valid_cell, try_capture_observation


def _observe() -> BoardObservation | ToolOutcome:
    observed = try_capture_observation("assert")
    return observed


def _board_text(observation: BoardObservation) -> str:
    return " / ".join("".join(cell or "." for cell in row) for row in observation.board)


def _unusable(observation: BoardObservation) -> str | None:
    if not observation.parse_ok:
        return observation.summary or "UIAutomator XML could not be parsed"
    return None


@tool
def get_board_state() -> ToolOutcome:
    """Return a normalized 3x3 board from visible accessibility evidence."""
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump(), evidence=observed.evidence)
    if observed.visible_cells == 0:
        return failed(
            "board cells are not exposed in the accessibility tree; cannot report marks from UI evidence",
            data=observed.model_dump(),
            evidence=observed.evidence,
        )
    return passed(
        f"observed board {_board_text(observed)}",
        data=observed.model_dump(),
        evidence=observed.evidence,
    )


@tool
def get_current_turn() -> ToolOutcome:
    """Return the visible current-player indicator."""
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    if not observed.current_turn:
        return failed("current turn is not visible", data=observed.model_dump())
    return passed(f"current turn is {observed.current_turn}", data=observed.model_dump())


@tool
def get_game_status() -> ToolOutcome:
    """Return playing, won, draw, or unknown from visible UI evidence."""
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    return passed(f"game status is {observed.game_status}", data=observed.model_dump())


@tool
def assert_current_turn(mark: str) -> ToolOutcome:
    """Assert that the visible turn indicator is the expected player.

    Args:
        mark: Expected current player, X or O.
    """
    if mark not in {"X", "O"}:
        return failed("turn mark must be X or O")
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    if observed.current_turn != mark:
        return failed(
            f"expected turn {mark} but observed {observed.current_turn or 'none'}",
            data=observed.model_dump(),
        )
    return passed(f"current turn is {mark}", data=observed.model_dump())


@tool
def assert_cell_empty(row: int, column: int) -> ToolOutcome:
    """Assert that one observed cell has no X or O mark.

    Args:
        row: Zero-based board row (0-2).
        column: Zero-based board column (0-2).
    """
    if not is_valid_cell(row, column):
        return failed("row and column must be 0..2")
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    if observed.visible_cells == 0:
        return failed(
            f"cannot verify an empty cell at ({row},{column}): cell marks are not exposed in the UI tree",
            data=observed.model_dump(),
        )
    actual = observed.board[row][column]
    if actual:
        return failed(
            f"expected empty at ({row},{column}) but observed {actual}",
            data=observed.model_dump(),
        )
    return passed(f"observed empty cell at ({row},{column})", data=observed.model_dump())


@tool
def assert_control_visible(text: str) -> ToolOutcome:
    """Assert that a labeled control is present in the visible UI.

    Args:
        text: Visible text or content description of the control.
    """
    label = (text or "").strip()
    if not label:
        return failed("text must be a non-empty control label")
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    if label.lower() not in observed.summary.lower():
        return failed(f"control not visible: {label}", data=observed.model_dump())
    return passed(f"visible control: {label}", data=observed.model_dump())


@tool
def assert_cell_mark(row: int, column: int, mark: str) -> ToolOutcome:
    """Assert that one observed cell contains the expected mark.

    Args:
        row: Zero-based board row (0-2).
        column: Zero-based board column (0-2).
        mark: Expected mark, X or O.
    """
    if not is_valid_cell(row, column) or mark not in {"X", "O"}:
        return failed("row and column must be 0..2 and mark must be X or O")
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    if observed.visible_cells == 0:
        return failed(
            f"cannot verify {mark} at ({row},{column}): cell marks are not exposed in the UI tree",
            data=observed.model_dump(),
        )
    actual = observed.board[row][column]
    if actual != mark:
        return failed(
            f"expected {mark} at ({row},{column}) but observed {actual or 'empty'}",
            data=observed.model_dump(),
        )
    return passed(f"observed {mark} at ({row},{column})", data=observed.model_dump())


@tool
def assert_board_empty() -> ToolOutcome:
    """Assert that no X or O marks are visible on labeled board cells."""
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    if observed.visible_cells == 0:
        return failed(
            "cannot verify an empty board: cell marks are not exposed in the UI tree",
            data=observed.model_dump(),
        )
    occupied = [
        f"({row},{column})={observed.board[row][column]}"
        for row in range(3)
        for column in range(3)
        if observed.board[row][column]
    ]
    if occupied:
        return failed(f"board is not empty: {', '.join(occupied)}", data=observed.model_dump())
    return passed("board is empty", data=observed.model_dump())


@tool
def assert_winner(mark: str) -> ToolOutcome:
    """Assert that a visible win announcement includes the expected mark.

    Args:
        mark: Expected winner, X or O.
    """
    if mark not in {"X", "O"}:
        return failed("winner mark must be X or O")
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    haystack = f"{observed.summary} {observed.current_turn}".lower()
    if observed.game_status != "won" or mark.lower() not in haystack:
        return failed(f"no visible win for {mark}", data=observed.model_dump())
    return passed(f"{mark} win was visible", data=observed.model_dump())


@tool
def assert_draw() -> ToolOutcome:
    """Assert that a visible draw or tie status is present."""
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    if observed.game_status != "draw":
        return failed("draw status was not visible", data=observed.model_dump())
    return passed("draw was visible", data=observed.model_dump())


@tool
def assert_reset_state() -> ToolOutcome:
    """Assert that the board is empty and it is Player X's turn."""
    empty = assert_board_empty()
    if empty.failed():
        return empty
    observed = _observe()
    if isinstance(observed, ToolOutcome):
        return observed
    if reason := _unusable(observed):
        return failed(reason, data=observed.model_dump())
    if observed.current_turn != "X":
        return failed(
            f"expected Player X to move after reset, observed {observed.current_turn or 'none'}",
            data=observed.model_dump(),
        )
    return passed("board is empty and it is Player X's turn", data=observed.model_dump())
