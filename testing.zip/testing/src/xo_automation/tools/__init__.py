"""Agent-callable mobile, game, assertion, task, and storage tools."""

from xo_automation.tools.assertions import (
    assert_board_empty,
    assert_cell_empty,
    assert_cell_mark,
    assert_control_visible,
    assert_current_turn,
    assert_draw,
    assert_reset_state,
    assert_winner,
    get_board_state,
    get_current_turn,
    get_game_status,
)
from xo_automation.tools.game import (
    background_app,
    play_moves,
    reset_game,
    resume_app,
    start_new_game,
    tap_cell,
    wait_for_game_state,
)
from xo_automation.tools.mobile import (
    check_device_connection,
    get_device_info,
    get_screen_elements,
    is_app_installed,
    launch_app,
    press_back,
    stop_app,
    take_screenshot,
    tap_element_by_description,
    tap_element_by_id,
    tap_element_by_text,
    tap_screen,
)
from xo_automation.tools.storage import record_step, save_report
from xo_automation.tools.task_manager import (
    finalize_test_plan,
    get_next_task,
    get_plan_progress,
    init_test_plan,
    mark_task_complete,
)

DEVICE_TOOLS = [
    check_device_connection,
    get_device_info,
    is_app_installed,
    launch_app,
    stop_app,
    get_screen_elements,
    tap_screen,
    tap_element_by_text,
    tap_element_by_id,
    tap_element_by_description,
    press_back,
    take_screenshot,
]

OBSERVER_TOOLS = [
    get_screen_elements,
    get_board_state,
    get_current_turn,
    get_game_status,
    take_screenshot,
]

ORCHESTRATOR_TOOLS = [
    check_device_connection,
    get_device_info,
    start_new_game,
    reset_game,
    tap_cell,
    play_moves,
    wait_for_game_state,
    background_app,
    resume_app,
    assert_cell_mark,
    assert_cell_empty,
    assert_board_empty,
    assert_current_turn,
    assert_control_visible,
    assert_winner,
    assert_draw,
    assert_reset_state,
    record_step,
    take_screenshot,
]

__all__ = [name for name in globals() if not name.startswith("_")]
