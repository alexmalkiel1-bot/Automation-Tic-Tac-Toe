"""Live state management for Markdown test plans."""

from pathlib import Path
import re

from xo_automation.models import ToolOutcome
from xo_automation.parsers.markdown_plan import parse_plan
from xo_automation.runtime import current, reset, reset_plan_file, utc_now
from xo_automation.tools.compat import tool
from xo_automation.tools.results import failed, passed


def _plan() -> dict | None:
    context = current()
    return context.plan_state if context else None


def task_counts() -> dict[str, int]:
    tasks = (_plan() or {}).get("tasks", [])
    return {
        "completed": sum(task["status"] == "completed" for task in tasks),
        "failed": sum(task["status"] == "failed" for task in tasks),
        "skipped": sum(task["status"] == "skipped" for task in tasks),
        "pending": sum(task["status"] == "pending" for task in tasks),
    }


def structured_plan_has_pending_tasks() -> bool:
    return task_counts()["pending"] > 0


def peek_next_task() -> dict | None:
    context = current()
    plan = _plan()
    if plan is None:
        return None
    for task in plan["tasks"]:
        if task["status"] == "pending":
            task["started_at"] = task["started_at"] or utc_now()
            if context:
                context.current_task_name = task["name"]
            return task
    return None


def remaining_pending() -> int:
    return task_counts()["pending"]


def _live_plan_paths() -> list[Path]:
    context = current()
    plan = _plan()
    paths: list[Path] = []
    if plan and plan.get("file_path"):
        paths.append(Path(plan["file_path"]))
    if context:
        paths.append(context.source_plan_path)
        paths.append(context.plan_path)
    unique: list[Path] = []
    seen: set[Path] = set()
    for path in paths:
        resolved = path.expanduser().resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        unique.append(path)
    return unique


def _read_live_plan() -> str:
    plan = _plan()
    if plan is None:
        raise RuntimeError("no test plan is initialized")
    return Path(plan["file_path"]).read_text(encoding="utf-8")


def _write_live_plan(content: str) -> None:
    for path in _live_plan_paths():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")


@tool
def init_test_plan(plan_file: str) -> ToolOutcome:
    """Parse a structured Markdown plan and load it as the current run contract.

    Args:
        plan_file: Path to the source Markdown plan. The runner resets it, then updates it live.
    """
    context = current()
    source = Path(plan_file).expanduser().resolve()
    write_path = source
    if context:
        source = context.source_plan_path
        write_path = context.source_plan_path
    reset_plan_file(source)
    plan = parse_plan(source)
    tasks = []
    for item in (*plan.prerequisites, *plan.cases):
        tasks.append(
            {
                "name": item.name,
                "type": item.task_type,
                "ref": item.reference,
                "resolved_path": item.resolved_path,
                "status": "completed" if item.checked else "pending",
                "started_at": "",
                "finished_at": "",
            }
        )
    state = {
        "file_path": str(write_path),
        "plan_id": plan.plan_id,
        "plan_name": plan.name,
        "tasks": tasks,
        "start_time": utc_now(),
    }
    if context:
        context.plan_state = state
        context.report.test_plan_name = plan.plan_id
    else:
        from xo_automation.runtime import init_session

        created = init_session(plan.plan_id, str(source), str(source.parent / "reports"))
        state["file_path"] = str(created.source_plan_path)
        created.plan_state = state
        created.source_plan_path = source
    return passed(
        f"Loaded plan {plan.plan_id}: {len(plan.prerequisites)} prerequisites, {len(plan.cases)} test cases",
        data={"plan_id": plan.plan_id, "tasks": len(tasks)},
    )


@tool
def get_next_task() -> ToolOutcome:
    """Return the next pending prerequisite or test case, or report that the plan is done."""
    if _plan() is None:
        return failed("no test plan is initialized")
    task = peek_next_task()
    if task is None:
        return passed("All tasks completed")
    return passed(
        f"{task['type'].upper()}: {task['name']} | {task['ref']}",
        data=task,
    )


@tool
def mark_task_complete(task_name: str, status: str = "completed") -> ToolOutcome:
    """Mark one task completed, failed, or skipped and update the live source plan.

    Args:
        task_name: Exact or unique substring of the task name.
        status: Terminal status: completed, failed, or skipped.
    """
    plan = _plan()
    if plan is None:
        return failed("no test plan is initialized")
    if status not in {"completed", "failed", "skipped"}:
        return failed("status must be completed, failed, or skipped")
    matches = [item for item in plan["tasks"] if item["name"].lower() == task_name.lower()]
    if not matches:
        matches = [item for item in plan["tasks"] if task_name.lower() in item["name"].lower()]
    if len(matches) != 1:
        return failed(f"task not found uniquely: {task_name}")
    task = matches[0]
    task["status"] = status
    task["finished_at"] = utc_now()
    content = _read_live_plan()
    target = re.escape(task["ref"] if task["type"] == "prerequisite" else task["name"])
    updated, count = re.subn(rf"^- \[ \](?=.*{target})", "- [x]", content, count=1, flags=re.MULTILINE)
    if count:
        _write_live_plan(updated)
    return passed(f"Marked '{task['name']}' as {status} [x]", data={"name": task["name"], "status": status})


@tool
def get_plan_progress() -> ToolOutcome:
    """Return the current checkbox-style progress of the loaded plan."""
    plan = _plan()
    if plan is None:
        return failed("no test plan is initialized")
    lines = [f"Plan: {plan['plan_id']} ({plan['plan_name']})", "", "Tasks:"]
    lines.extend(
        f"[{'x' if task['status'] != 'pending' else ' '}] {task['name']} ({task['status']})" for task in plan["tasks"]
    )
    return passed("\n".join(lines), data={"tasks": plan["tasks"]})


@tool
def finalize_test_plan(summary_notes: str = "") -> ToolOutcome:
    """Write the execution summary to the live source plan. Refuses if tasks are still pending.

    Args:
        summary_notes: Optional notes appended to the generated summary.
    """
    plan = _plan()
    if plan is None:
        return failed("no test plan is initialized")
    if structured_plan_has_pending_tasks():
        return failed("cannot finalize while tasks remain pending")
    counts = task_counts()
    status = "PASSED" if counts["failed"] == 0 else "FAILED"
    summary = (
        f"## Execution Summary\n\n**Status:** {status}\n**Executed:** {utc_now()}\n\n"
        f"**Results:**\n- Completed: {counts['completed']}\n- Failed: {counts['failed']}\n"
        f"- Skipped: {counts['skipped']}\n\n"
        f"**Notes:**\n{summary_notes or 'None'}\n"
    )
    content = _read_live_plan()
    marker = "## Execution Summary"
    content = content.split(marker, 1)[0].rstrip() if marker in content else content.rstrip()
    _write_live_plan(f"{content}\n\n{summary}")
    return passed(
        "Execution summary written to plan file",
        data={"status": status, **counts},
    )


def clear_plan() -> None:
    reset()
