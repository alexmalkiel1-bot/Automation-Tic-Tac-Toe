"""Parser for structured Markdown test plans and cases."""

from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import re


_TOOL_RE = re.compile(r"^[-*]\s+\*\*Tool:\*\*\s+@tool:(\w+)\((.*)\)$")
_TOOL_REF_RE = re.compile(r"^@tool:(\w+)\((.*)\)$")
_PREREQUISITE_RE = re.compile(r"^-\s+\[([ xX])\]\s+@tool:(\w+)\((.*)\)$")
_CASE_RE = re.compile(r"^-\s+\[([ xX])\]\s+\[([^]]+)\]\(([^)]+)\)$")


@dataclass(frozen=True)
class MarkdownStep:
    number: int
    title: str
    action: str
    tool_name: str
    tool_arguments: str
    parsed_arguments: dict[str, Any]
    expected_result: str


@dataclass(frozen=True)
class MarkdownTestCase:
    case_id: str
    name: str
    path: Path
    steps: tuple[MarkdownStep, ...]


@dataclass(frozen=True)
class MarkdownPlanTask:
    name: str
    task_type: str
    reference: str
    checked: bool
    resolved_path: str = ""


@dataclass(frozen=True)
class MarkdownPlan:
    plan_id: str
    name: str
    path: Path
    prerequisites: tuple[MarkdownPlanTask, ...]
    cases: tuple[MarkdownPlanTask, ...]


def parse_tool_arguments(raw: str) -> dict[str, Any]:
    """Parse `name=value` tool arguments without eval."""
    text = raw.strip()
    if not text:
        return {}
    tree = ast.parse(f"fn({text})", mode="eval")
    call = tree.body
    if not isinstance(call, ast.Call):
        raise ValueError(f"invalid tool arguments: {raw}")
    if call.args:
        raise ValueError("positional tool arguments are not supported")
    parsed: dict[str, Any] = {}
    for keyword in call.keywords:
        if keyword.arg is None:
            raise ValueError("splat tool arguments are not supported")
        parsed[keyword.arg] = ast.literal_eval(keyword.value)
    return parsed


def parse_tool_reference(reference: str) -> tuple[str, dict[str, Any]]:
    """Parse an `@tool:name(args)` reference from a plan prerequisite or case step."""
    match = _TOOL_REF_RE.match((reference or "").strip())
    if not match:
        raise ValueError(f"invalid tool reference: {reference}")
    return match.group(1), parse_tool_arguments(match.group(2))


def _heading_value(content: str, prefix: str) -> str:
    for line in content.splitlines():
        if line.startswith(prefix):
            return line[len(prefix) :].strip()
    return ""


def parse_plan(plan_file: str | Path) -> MarkdownPlan:
    path = Path(plan_file).expanduser().resolve()
    content = path.read_text(encoding="utf-8")
    if "## 1. Prerequisites" not in content or "## 2. Test Cases" not in content:
        raise ValueError("Plan must contain ## 1. Prerequisites and ## 2. Test Cases")

    plan_id = _heading_value(content, "**ID:**")
    title = _heading_value(content, "# Test Plan:")
    prerequisites = []
    cases = []
    section = ""
    for line in content.splitlines():
        if line.startswith("## 1. Prerequisites"):
            section = "prerequisites"
            continue
        if line.startswith("## 2. Test Cases"):
            section = "cases"
            continue
        if line.startswith("## "):
            section = ""
        if section == "prerequisites":
            match = _PREREQUISITE_RE.match(line)
            if match:
                checked, name, args = match.groups()
                parse_tool_arguments(args)
                reference = f"@tool:{name}({args})"
                prerequisites.append(MarkdownPlanTask(name, "prerequisite", reference, checked.lower() == "x"))
        elif section == "cases":
            match = _CASE_RE.match(line)
            if match:
                checked, display_name, reference = match.groups()
                resolved = (path.parent / reference).resolve()
                if not resolved.exists():
                    raise ValueError(f"Case file not found: {reference}")
                parse_case(resolved)
                cases.append(
                    MarkdownPlanTask(
                        display_name,
                        "test_case",
                        reference,
                        checked.lower() == "x",
                        str(resolved),
                    )
                )
    if not plan_id or not title:
        raise ValueError("Plan must contain **ID:** and # Test Plan: metadata")
    return MarkdownPlan(plan_id, title, path, tuple(prerequisites), tuple(cases))


def parse_case(case_file: str | Path) -> MarkdownTestCase:
    path = Path(case_file).expanduser().resolve()
    content = path.read_text(encoding="utf-8")
    case_title = _heading_value(content, "# Test Case:")
    case_id = _heading_value(content, "**ID:**")
    steps: list[MarkdownStep] = []
    lines = content.splitlines()
    for index, line in enumerate(lines):
        heading = re.match(r"^### Step (\d+):\s*(.+)$", line)
        if not heading:
            continue
        number = int(heading.group(1))
        title = heading.group(2).strip()
        fields: dict[str, str] = {}
        for field_line in lines[index + 1 : index + 6]:
            field = re.match(r"^- \*\*(Action|Tool|Expected Result):\*\*\s*(.*)$", field_line)
            if field:
                fields[field.group(1)] = field.group(2).strip()
        tool_match = _TOOL_RE.match(f"- **Tool:** {fields.get('Tool', '')}")
        if not tool_match:
            raise ValueError(f"Step {number} in {path} has an invalid or missing tool")
        tool_name, arguments = tool_match.groups()
        parsed = parse_tool_arguments(arguments)
        if not fields.get("Action") or not fields.get("Expected Result"):
            raise ValueError(f"Step {number} in {path} must define Action and Expected Result")
        steps.append(
            MarkdownStep(number, title, fields["Action"], tool_name, arguments, parsed, fields["Expected Result"])
        )
    if not case_id or not case_title or not steps:
        raise ValueError(f"Case {path} must contain ID, title, and at least one step")
    return MarkdownTestCase(case_id, case_title, path, tuple(steps))
