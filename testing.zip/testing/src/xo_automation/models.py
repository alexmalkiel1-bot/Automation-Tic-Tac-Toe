"""Typed models for observations, tool results, and Markdown reports."""

from typing import Any, Literal

from pydantic import BaseModel, Field


CellMark = Literal["X", "O", ""]
StepStatus = Literal["pass", "fail", "skipped", "pending"]
TaskStatus = Literal["completed", "failed", "skipped"]
GameStatus = Literal["playing", "won", "draw", "unknown"]


class ToolOutcome(BaseModel):
    """Structured result returned by every agent-facing tool."""

    status: Literal["pass", "fail"]
    message: str
    data: dict[str, Any] = Field(default_factory=dict)
    evidence: list[str] = Field(default_factory=list)

    def failed(self) -> bool:
        return self.status == "fail"


class BoardObservation(BaseModel):
    board: list[list[CellMark]] = Field(default_factory=lambda: [["", "", ""] for _ in range(3)])
    current_turn: str = ""
    game_status: GameStatus = "unknown"
    visible_cells: int = 0
    parse_ok: bool = True
    positions_logged: int | None = None
    summary: str = ""
    evidence: list[str] = Field(default_factory=list)


class TaskVerdict(BaseModel):
    """Structured verdict produced after one plan task."""

    task_name: str
    status: TaskStatus
    notes: str = ""
    actual_result: str = ""


class PlanRunResult(BaseModel):
    plan_id: str = ""
    completed: int = 0
    failed: int = 0
    skipped: int = 0
    pending: int = 0
    report_path: str = ""
    notes: str = ""

    @property
    def passed(self) -> bool:
        return self.failed == 0 and self.pending == 0


class TestStepResult(BaseModel):
    task_name: str = ""
    step_number: int
    description: str
    expected_result: str
    actual_result: str = ""
    status: StepStatus = "pending"
    timestamp: str = ""
    notes: str = ""
    evidence: list[str] = Field(default_factory=list)


class TestReport(BaseModel):
    test_plan_name: str = ""
    test_plan_path: str = ""
    app_name: str = "Tic-Tac-Toe"
    app_package: str = "com.qatest.xo_qa_challenge"
    device_id: str = ""
    start_time: str = ""
    end_time: str = ""
    test_steps: list[TestStepResult] = Field(default_factory=list)
    summary: str = ""

    @property
    def total_steps(self) -> int:
        return len(self.test_steps)

    @property
    def passed_steps(self) -> int:
        return sum(step.status == "pass" for step in self.test_steps)

    @property
    def failed_steps(self) -> int:
        return sum(step.status == "fail" for step in self.test_steps)

    @property
    def skipped_steps(self) -> int:
        return sum(step.status == "skipped" for step in self.test_steps)
