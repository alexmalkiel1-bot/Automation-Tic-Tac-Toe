"""Strands hooks that enforce observe-act-verify and capture failure evidence."""

from __future__ import annotations

from typing import Any

from strands.hooks import AfterToolCallEvent, BeforeToolCallEvent, BeforeToolsEvent, HookProvider, HookRegistry

from xo_automation.config import MAX_ACTION_RETRIES
from xo_automation.runtime import current
from xo_automation.tools.mobile import save_screenshot
from xo_automation.tools.results import is_failure as result_failed

MUTATING_TOOLS = {
    "launch_app",
    "stop_app",
    "tap_screen",
    "tap_element_by_text",
    "tap_element_by_id",
    "tap_element_by_description",
    "press_back",
    "start_new_game",
    "reset_game",
    "tap_cell",
    "play_moves",
    "background_app",
    "resume_app",
}

OBSERVE_TOOLS = {
    "get_screen_elements",
    "get_board_state",
    "get_current_turn",
    "get_game_status",
    "assert_cell_mark",
    "assert_cell_empty",
    "assert_board_empty",
    "assert_current_turn",
    "assert_control_visible",
    "assert_winner",
    "assert_draw",
    "assert_reset_state",
    "take_screenshot",
    "observe_screen",
}


def tool_names_from_message(message: Any) -> list[str]:
    if message is None:
        return []
    content = message.get("content") if isinstance(message, dict) else getattr(message, "content", None)
    names: list[str] = []
    for block in content or []:
        if not isinstance(block, dict):
            continue
        use = block.get("toolUse")
        if isinstance(use, dict) and use.get("name"):
            names.append(str(use["name"]))
    return names


class ObserveActVerifyHook(HookProvider):
    """Allow only one mutating tool per model turn and require observation between mutations."""

    def register_hooks(self, registry: HookRegistry, **kwargs: Any) -> None:
        registry.add_callback(BeforeToolsEvent, self.before_tools)
        registry.add_callback(BeforeToolCallEvent, self.before_tool)
        registry.add_callback(AfterToolCallEvent, self.after_tool)

    def before_tools(self, event: BeforeToolsEvent) -> None:
        names = tool_names_from_message(event.message)
        mutating = [name for name in names if name in MUTATING_TOOLS]
        if len(mutating) > 1:
            event.cancel = (
                "Use one screen-changing tool at a time. "
                f"Requested mutating tools: {', '.join(mutating)}"
            )

    def before_tool(self, event: BeforeToolCallEvent) -> None:
        name = event.tool_use.get("name", "")
        context = current()
        if name in MUTATING_TOOLS and context and not context.observed_since_mutation:
            event.cancel_tool = (
                f"Observe the UI before calling {name}. "
                "Use observe_screen, an assertion, or get_screen_elements first."
            )

    def after_tool(self, event: AfterToolCallEvent) -> None:
        name = event.tool_use.get("name", "")
        context = current()
        if name in OBSERVE_TOOLS and context:
            context.observed_since_mutation = True
        if name in MUTATING_TOOLS and context:
            context.observed_since_mutation = False
        if not result_failed(event.result):
            if context:
                context.mutation_retries[name] = 0
            return
        retries = 0
        if context:
            retries = context.mutation_retries.get(name, 0)
            if name in MUTATING_TOOLS and retries < MAX_ACTION_RETRIES:
                context.mutation_retries[name] = retries + 1
                event.retry = True
                return
        try:
            path = save_screenshot(f"fail-{name}")
            if isinstance(event.result, dict):
                content = list(event.result.get("content") or [])
                content.append({"text": f"failure evidence: {path}"})
                event.result = {**event.result, "content": content}
        except Exception:
            pass
