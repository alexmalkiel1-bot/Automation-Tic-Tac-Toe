"""Command-line interface for plan validation and execution."""

from __future__ import annotations

import argparse
import os
from pathlib import Path

from xo_automation.config import MODEL_API_BASE, MODEL_ID
from xo_automation.parsers.markdown_plan import parse_plan


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run a Markdown Tic-Tac-Toe mobile test plan")
    parser.add_argument(
        "--test-plan",
        "--plan",
        dest="test_plan",
        required=True,
        help="Path to a structured Markdown test plan",
    )
    parser.add_argument("--output", default="smoke.md", help="Markdown report file to write")
    parser.add_argument("--output-dir", default="reports", help="Directory for run copies and screenshot evidence")
    parser.add_argument(
        "--api-key",
        default=os.getenv("XO_API_KEY") or os.getenv("LITELLM_API_KEY"),
        help="LiteLLM / Bedrock API key. Prefer XO_API_KEY if you do not want it on the command line.",
    )
    parser.add_argument(
        "--model-id",
        default=MODEL_ID,
        help="LiteLLM model id. Defaults to XO_MODEL_ID when set.",
    )
    parser.add_argument(
        "--api-base",
        default=os.getenv("XO_API_BASE") or MODEL_API_BASE,
        help="LiteLLM proxy base URL. Defaults to XO_API_BASE when set.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Parse the plan without connecting to a device or model")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    plan = parse_plan(args.test_plan)
    print(f"Plan: {plan.plan_id} - {plan.name}")
    print(f"Prerequisites: {len(plan.prerequisites)}")
    print(f"Test cases: {len(plan.cases)}")
    if args.dry_run:
        for task in (*plan.prerequisites, *plan.cases):
            print(f"- {task.task_type}: {task.name}")
        return 0
    if not args.api_key:
        print("error: --api-key is required for a live run (or set XO_API_KEY / LITELLM_API_KEY)")
        return 2
    from xo_automation.agent import run_plan

    result = run_plan(
        str(Path(args.test_plan)),
        output_dir=args.output_dir,
        report_file=args.output,
        api_key=args.api_key,
        model_id=args.model_id,
        api_base=args.api_base,
    )
    print(
        f"Completed={result.completed} failed={result.failed} "
        f"skipped={result.skipped} pending={result.pending}"
    )
    if result.report_path:
        print(f"Report: {result.report_path}")
    return 0 if result.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
