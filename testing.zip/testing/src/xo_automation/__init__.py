"""Tic-Tac-Toe mobile automation package."""

from xo_automation.config import APP_NAME, APP_PACKAGE

__all__ = ["APP_NAME", "APP_PACKAGE"]
