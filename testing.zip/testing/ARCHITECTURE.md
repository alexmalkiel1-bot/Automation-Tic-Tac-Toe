# Tic-Tac-Toe AI Mobile Automation Architecture

> Version: 1.0
> Last Updated: 2026-09-23
> Status: Initial implementation design
> App Under Test: `com.qatest.xo_qa_challenge`

This document is the definitive, self-contained architecture for a Python and Markdown mobile automation project driven by Strands Agents. It is specific to the Tic-Tac-Toe application.

## 1. Executive Summary

The project is an agent-driven Android mobile testing framework. QA scenarios are authored in Markdown, Python tools execute device interactions, and Strands Agents orchestrates observation, action, verification, recovery, and reporting.

The system must test the real Tic-Tac-Toe app rather than simulate game logic in Python. The automation observes the rendered board and UI, taps cells, validates turns and game outcomes, and records evidence.

Core principles:

- Markdown is the human-readable test data and live execution state.
- Python owns deterministic device actions, parsing, state management, and reporting.
- Strands Agents owns test orchestration and adaptive decisions.
- The app remains the source of truth for game behavior.
- Every result is based on observed UI state, not on an assumed internal board model.

## 2. System Boundaries

### In scope

- Android device or emulator control
- App launch, reset, and readiness checks
- Tic-Tac-Toe board inspection
- Cell selection and move execution
- X/O turn validation
- Row, column, and diagonal win validation
- Draw and game-over validation
- New-game/reset validation
- Markdown test-plan execution
- Markdown reporting
- Screenshots and observed UI evidence

### Out of scope for the first version

- iOS automation
- Network/API testing
- Image-based visual regression comparison
- Solving game strategy as a product feature
- Reimplementing the app's game engine in the test framework

## 3. Architecture Overview

```text
Markdown Test Plans and Cases
            |
            v
+-----------------------------+
| Strands Agent Orchestrator  |
| observe -> act -> verify    |
+-----------------------------+
            |
            v
+-----------------------------+
| Python @tool functions      |
| task manager, game flows,   |
| assertions, evidence, I/O   |
+-----------------------------+
            |
            v
+-----------------------------+
| Android Mobile Adapter      |
| launch, inspect, tap, back, |
| screenshot, reset           |
+-----------------------------+
            |
            v
+-----------------------------+
| com.qatest.xo_qa_challenge  |
+-----------------------------+
            |
            v
Reports: Markdown and screenshots
```

The agent may choose the next action, but low-level device operations remain Python tools. The application UI is observed after state-changing actions.

## 4. Target Directory Structure

```text
testing/
├── ARCHITECTURE.md
├── pyproject.toml                 # Python dependencies and commands
├── README.md
├── src/
│   └── xo_automation/
│       ├── __init__.py
│       ├── agent.py               # Strands Agent construction and run loop
│       ├── config.py              # Package name and runtime configuration
│       ├── models.py              # Pydantic report and observation models
│       ├── prompts.py             # Agent behavior and execution rules
│       ├── parsers/
│       │   ├── __init__.py
│       │   └── markdown_plan.py   # Markdown plan and case parsing
│       ├── tools/
│       │   ├── __init__.py
│       │   ├── mobile.py          # Android adapter boundary
│       │   ├── game.py            # Tic-Tac-Toe composite flows
│       │   ├── assertions.py      # Observable game assertions
│       │   ├── task_manager.py    # Markdown task state manager
│       │   └── storage.py         # Reports and evidence repository
│       └── cli.py
├── tests/
│   ├── plans/
│   │   └── smoke.md
│   └── cases/
│       ├── board/
│       ├── gameplay/
│       └── reset/
├── reports/                       # Generated; do not hand-edit
│   └── README.md
└── screenshots/                   # Generated evidence, grouped by run
```

The `testing` folder is the exclusive project root. Future implementation files belong here.

## 5. Design Patterns

### 5.1 Separation of concerns

Markdown defines test intent. Python tools execute behavior. Strands Agents orchestrates the workflow. Reports persist results. No layer should absorb the responsibility of another layer.

### 5.2 Keyword-driven testing

Markdown steps reference callable Python tools using `@tool:function_name(...)`. The agent resolves those names to registered Strands tools. Tool names must be stable and documented.

### 5.3 Modular testing

A test case is an independent Markdown instruction set. A plan composes prerequisites and cases. Cases should be reusable and should not depend on hidden state from another case unless the plan explicitly defines that prerequisite.

### 5.4 Facade pattern

`tools/game.py` provides multi-action flows such as starting a clean game or playing a prescribed sequence. A facade is allowed only when it composes two or more lower-level mobile or assertion operations.

### 5.5 State manager pattern

`tools/task_manager.py` owns the in-memory execution state and updates Markdown checkboxes. It provides one source of truth for pending, completed, failed, and skipped tasks during a run.

### 5.6 Repository pattern

`tools/storage.py` owns report and screenshot persistence. Agent and tool code should not contain scattered report file-writing logic.

### 5.7 Observe-act-verify loop

Each meaningful action follows this sequence:

1. Observe the current UI and board state.
2. Select one action appropriate to the current state.
3. Execute one screen-changing mobile operation.
4. Observe again.
5. Compare the result with the expected outcome.
6. Record the verdict and evidence.

### 5.8 Dependency inversion

Game flows depend on a stable mobile adapter interface. The mobile adapter must not import app-specific flows or test plans.

## 6. Python Logic Layer

### 6.1 Configuration

`config.py` defines:

```python
APP_PACKAGE = "com.qatest.xo_qa_challenge"
APP_NAME = "Tic-Tac-Toe"
MAX_ACTION_RETRIES = 2
```

Device selection and model/API configuration must come from environment variables or CLI arguments. Secrets must never be written to Markdown files.

### 6.2 Mobile adapter tools

The adapter exposes the smallest useful primitives. Exact implementation may use the existing Android automation backend, but the rest of the project must depend on these stable tool contracts:

- `check_device_connection() -> str`
- `get_device_info() -> str`
- `is_app_installed(package_name: str) -> str`
- `launch_app(package_name: str) -> str`
- `stop_app(package_name: str) -> str`
- `get_screen_elements() -> str`
- `tap_screen(x: int, y: int) -> str`
- `tap_element_by_text(text: str, index: int = 0) -> str`
- `tap_element_by_id(resource_id: str, index: int = 0) -> str`
- `press_back() -> str`
- `take_screenshot() -> str`

A screen-changing tool must return a useful success or failure string and must not hide exceptions that affect the test verdict.

### 6.3 Game tools

`tools/game.py` contains app-specific composite operations. Initial tools:

- `start_new_game()`: stop and relaunch the app, then verify the board is ready.
- `reset_game()`: invoke the visible reset/new-game control and verify an empty board.
- `tap_cell(row: int, column: int)`: tap one board cell after validating coordinates.
- `play_moves(moves: str)`: execute a controlled sequence only when explicitly requested by a test. Each move is observed individually.
- `wait_for_game_state(state: str)`: passively wait for a stable state such as `playing`, `won`, or `draw`.

A game facade must not claim a win, draw, or turn transition based only on the requested tap. It must inspect the resulting UI.

### 6.4 Observation and assertion tools

`tools/assertions.py` translates visible UI evidence into test assertions. Initial contracts:

- `get_board_state() -> str`: return a normalized 3x3 representation, for example `[["X", "", "O"], ...]`, when the UI exposes enough evidence.
- `get_current_turn() -> str`: return the visible current-player indicator.
- `get_game_status() -> str`: return `playing`, `won`, `draw`, or `unknown`, with evidence.
- `assert_cell_mark(row: int, column: int, mark: str) -> str`
- `assert_board_empty() -> str`
- `assert_winner(mark: str) -> str`
- `assert_draw() -> str`
- `assert_reset_state() -> str`

Assertions must be based on `get_screen_elements()` and screenshots where useful. They must not calculate an expected result by duplicating the app's implementation and then report that calculation as observed behavior.

### 6.5 Task manager

`tools/task_manager.py` manages one loaded plan per process:

```python
_current_plan = {
    "file_path": "absolute/path/to/plan.md",
    "plan_id": "PLAN-SMOKE-001",
    "plan_name": "Basic game smoke test",
    "tasks": [
        {
            "name": "start_new_game",
            "type": "prerequisite",
            "ref": "@tool:start_new_game()",
            "status": "pending",
            "started_at": "",
            "finished_at": "",
        }
    ],
    "start_time": "2026-09-23T00:00:00Z",
}
```

Required functions:

- `init_test_plan(plan_file: str) -> str`
- `get_next_task() -> str`
- `mark_task_complete(task_name: str, status: str = "completed") -> str`
- `get_plan_progress() -> str`
- `finalize_test_plan(summary_notes: str = "") -> str`

`mark_task_complete` updates the matching Markdown checkbox. `finalize_test_plan` must refuse to write a final summary while tasks remain pending. Failed and skipped tasks must be explicitly transitioned so the run can finish honestly.

### 6.6 Storage and evidence

`tools/storage.py` owns:

- run initialization
- test metadata
- step results
- screenshots and evidence paths
- per-case Markdown reports
- overall Markdown reports

Reports must include the observed result, expected result, status, timestamp, and notes about retries or incidental UI friction.

## 7. Markdown Data Layer

### 7.1 Test plan format

Plans live under `tests/plans/` and orchestrate prerequisites and cases:

```markdown
# Test Plan: Tic-Tac-Toe Smoke

**ID:** PLAN-SMOKE-001
**App:** Tic-Tac-Toe (`com.qatest.xo_qa_challenge`)
**Created:** 2026-09-23

## 1. Prerequisites

- [ ] @tool:check_device_connection()
- [ ] @tool:start_new_game()

## 2. Test Cases

- [ ] [TC-001: Make a valid move](../cases/gameplay/valid_move.md)
- [ ] [TC-002: Reset a completed game](../cases/reset/reset_game.md)

## 3. Success Criteria

- The app launches successfully.
- Every case completes with an honest pass, fail, or skipped result.
- No task remains pending at finalization.

## Execution Summary
<!-- Auto-generated by task_manager.finalize_test_plan(). -->
```

### 7.2 Test case format

Cases live under `tests/cases/`:

```markdown
# Test Case: Make a Valid Move

**ID:** TC-001
**Category:** Gameplay
**Priority:** P0

## Objective

Verify that tapping an empty cell places the active player's mark.

## Prerequisites

- A clean game is visible.
- The board is empty.

## Test Steps

### Step 1: Tap the center cell
- **Action:** Select the center cell of the board.
- **Tool:** @tool:tap_cell(row=1, column=1)
- **Expected Result:** The active player's mark appears in the center cell and the turn changes or game status updates.

### Step 2: Verify the mark
- **Action:** Observe the board after the move.
- **Tool:** @tool:assert_cell_mark(row=1, column=1, mark="X")
- **Expected Result:** The center cell visibly contains X.

## Acceptance Criteria

- The move is accepted exactly once.
- The expected mark is visible in the selected cell.
- The result is recorded from observed UI state.
```

Rows and columns are zero-based unless a test case explicitly documents another convention. The board coordinate convention must remain consistent across all Python tools and Markdown cases.

### 7.3 Parsing rules

The parser must:

1. Recognize a structured plan by the exact `## 1. Prerequisites` and `## 2. Test Cases` sections.
2. Parse prerequisite lines matching `- [ ] @tool:function_name(args)`.
3. Parse case references matching `- [ ] [TC-...](relative/path.md)`.
4. Resolve case paths relative to the plan file.
5. Parse case step tool lines matching `- **Tool:** @tool:function_name(args)`.
6. Preserve the human-readable Action and Expected Result fields.
7. Reject malformed or ambiguous references before execution.
8. Treat checked items as already completed only when the plan is intentionally being resumed.

Argument parsing must use a structured parser rather than unsafe `eval`. Tool arguments must be validated by Python function signatures and type checks.

## 8. Agent Orchestration with Strands

The Strands Agent is responsible for control flow, not for hiding deterministic logic. Its system prompt must require:

- initialize the plan before executing structured tasks
- observe before acting
- use one screen-changing tool at a time
- observe after every screen-changing tool
- use the exact tool names referenced by Markdown
- validate expected results at a stable assertion checkpoint
- record each step after the verdict
- mark every task completed, failed, or skipped
- finalize only when no task is pending
- preserve truthful failures and avoid coercive extra actions

Structured execution loop:

```text
load plan
  -> init_test_plan(plan)
  -> get_next_task()
  -> execute one prerequisite or case
  -> observe and validate
  -> record result
  -> mark_task_complete(...)
  -> repeat until no pending tasks
  -> finalize_test_plan(...)
  -> save overall reports
```

The continuation loop should be bounded by a configurable maximum number of rounds. It must stop on user abort, device/session failure, initialization failure, or exhausted continuation rounds. A failed case alone must not silently terminate the plan when other tasks remain.

## 9. Execution and Verdict Rules

### 9.1 Mobile interaction rules

- Use a sequential tool executor.
- Execute one screen-changing action per agent turn.
- Observe before deciding the next action.
- Observe after every screen-changing action.
- Do not tap arbitrary coordinates when a stable text or resource identifier is available.
- Capture a screenshot on failure and when required for audit evidence.

### 9.2 Execution versus verdict

Execution handles the prescribed action and incidental friction such as a transient dialog or a delayed render. Verdict determines whether the expected product behavior is true.

The agent may retry an action within the configured limit when the failure is incidental. It may not perform unprescribed navigation solely to force the expected result and then report a pass.

A verdict must be based on the assertion checkpoint after the prescribed action has stabilized. `actual_result` must describe what was observed at that checkpoint.

### 9.3 Game-specific validation

The framework must validate, through the UI:

- an empty board at the beginning of a game
- only valid cells can be selected
- a selected cell receives the expected mark
- occupied cells are not overwritten
- turns alternate according to the app's visible behavior
- a row, column, or diagonal win is announced correctly
- a draw is announced when no winning line exists and no cells remain
- moves are blocked after game over when the app specifies that behavior
- reset/new game returns the board to its initial state

The test framework must not assume that X always starts unless the app or test explicitly establishes that condition.

## 10. Reporting

Each run creates a timestamped directory under `reports/` and may create screenshots under `screenshots/<run-id>/`.

### Overall report

The overall report includes:

- app package and device information
- plan identifier and source path
- start and end timestamps
- total, passed, failed, and skipped counts
- per-task results
- failure details and evidence paths
- agent notes and continuation information

### Per-step report

```markdown
### Step 1: Tap the center cell

| Field | Value |
|---|---|
| Description | Tap the center cell |
| Expected result | X appears in the center cell |
| Actual result | X was visible in row 1, column 1 |
| Status | PASS |
| Timestamp | 2026-09-23T12:00:00Z |
| Notes | None |
| Evidence | screenshots/2026-09-23_120000/TC-001-step-1.png |
```

Reports are generated artifacts and must not be hand-edited during a run.

## 11. Security and Reliability Rules

- Never hardcode API keys, passwords, or tokens.
- Never put secrets in Markdown plans or case files.
- Never use `eval` to parse Markdown tool arguments.
- Validate paths and prevent report output from escaping the project root unless explicitly configured.
- Keep device operations behind the mobile adapter.
- Make retries bounded and observable.
- Preserve user changes to plan files and avoid destructive rewrites.
- Do not claim success when the device is unavailable or the UI cannot be observed.

## 12. Implementation Phases

1. Create the Python project metadata and package structure under `testing/`.
2. Implement and verify the mobile adapter boundary against an available Android device or emulator.
3. Implement screen and board observation models without duplicating game logic.
4. Implement `start_new_game`, `reset_game`, and `tap_cell` facades.
5. Implement Markdown plan and case parsing.
6. Implement task state tracking and live checkbox updates.
7. Implement Strands Agent prompts, tool registration, and bounded continuation.
8. Implement reports, screenshots, and failure evidence.
9. Add Tic-Tac-Toe Markdown cases for valid moves, invalid moves, wins, draws, and reset.
10. Run the smoke plan on `com.qatest.xo_qa_challenge` and refine selectors based on observed UI evidence.

Each phase must have an executable verification check before the next phase begins.

## 13. Definition of Done

The first usable version is complete when:

- `testing/` contains the Python package and Markdown test data.
- The app package is configurable but defaults to `com.qatest.xo_qa_challenge`.
- A structured Markdown plan can be parsed and executed.
- The agent can launch the app, observe the board, tap a cell, and verify the resulting mark.
- Task checkboxes update during execution.
- Pending tasks cannot be silently finalized.
- Failed steps produce truthful reports and evidence.
- At least one smoke plan runs against a real device or emulator.
