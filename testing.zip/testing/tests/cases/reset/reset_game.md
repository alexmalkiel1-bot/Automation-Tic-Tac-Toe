# Test Case: Verify Reset / Restart Functionality

**ID:** TC-007
**Category:** Reset
**Priority:** P0

## Objective

Confirm the Restart button completely resets game state mid-game.

## Prerequisites

- A game is open.
- The reset control is visible.

## Test Steps

### Step 1: Reset to a clean board
- **Action:** Activate reset so the case starts from a known empty board.
- **Tool:** @tool:reset_game()
- **Expected Result:** An empty board is displayed.

### Step 2: Play mid-game moves
- **Action:** Make four moves so the board is no longer empty.
- **Tool:** @tool:play_moves(moves="0,0; 1,1; 0,1; 2,2")
- **Expected Result:** Several cells are marked.

### Step 3: Tap Restart
- **Action:** Activate the visible Restart / Reset control.
- **Tool:** @tool:reset_game()
- **Expected Result:** The game returns to a new initial state.

### Step 4: Verify the reset state
- **Action:** Observe the board and turn after reset.
- **Tool:** @tool:assert_reset_state()
- **Expected Result:** All cells are empty and it is Player X's turn.

## Acceptance Criteria

- The reset action completes.
- All grid cells clear.
- Player X is to move again.
