# Test Case: Verify Initial App Launch & Default UI State

**ID:** TC-001
**Category:** Launch
**Priority:** P0

## Objective

Ensure all UI elements render correctly when the game opens.

## Prerequisites

- App is freshly installed or reset.
- The plan already launched a clean game.

## Test Steps

### Step 1: Verify the board is empty
- **Action:** Inspect the 3x3 grid on the main screen.
- **Tool:** @tool:assert_board_empty()
- **Expected Result:** All 9 grid cells are completely empty.

### Step 2: Verify the default turn
- **Action:** Inspect the status indicator.
- **Tool:** @tool:assert_current_turn(mark="X")
- **Expected Result:** Status indicator displays Player X's turn.

### Step 3: Verify the reset control
- **Action:** Inspect the Restart / Reset button.
- **Tool:** @tool:assert_control_visible(text="Reset Game")
- **Expected Result:** A Restart / Reset button is visible and active.

## Acceptance Criteria

- A 3x3 grid is displayed.
- All 9 grid cells are empty.
- Player X is to move.
- The reset control is visible.
