# Test Case: Verify Alternating Turn Logic

**ID:** TC-002
**Category:** Gameplay
**Priority:** P0

## Objective

Validate that turns automatically alternate between Player X and Player O.

## Prerequisites

- A clean game is visible.

## Test Steps

### Step 1: Reset to a clean board
- **Action:** Activate reset so the case does not depend on leftover marks.
- **Tool:** @tool:reset_game()
- **Expected Result:** An empty board is displayed.

### Step 2: Tap the top-left cell
- **Action:** Tap Row 1, Column 1 (zero-based 0,0).
- **Tool:** @tool:tap_cell(row=0, column=0)
- **Expected Result:** Player X marks the top-left cell.

### Step 3: Verify X and O to move
- **Action:** Observe the mark and the status indicator.
- **Tool:** @tool:assert_cell_mark(row=0, column=0, mark="X")
- **Expected Result:** Cell (0,0) displays X.

### Step 4: Verify it is Player O's turn
- **Action:** Inspect the status indicator after the first move.
- **Tool:** @tool:assert_current_turn(mark="O")
- **Expected Result:** Status indicator updates to Player O's turn.

### Step 5: Tap the center cell
- **Action:** Tap Row 2, Column 2 (zero-based 1,1).
- **Tool:** @tool:tap_cell(row=1, column=1)
- **Expected Result:** Player O marks the center cell.

### Step 6: Verify O in the center
- **Action:** Observe the center cell after O's move.
- **Tool:** @tool:assert_cell_mark(row=1, column=1, mark="O")
- **Expected Result:** Cell (1,1) displays O.

### Step 7: Verify it is Player X's turn
- **Action:** Inspect the status indicator after the second move.
- **Tool:** @tool:assert_current_turn(mark="X")
- **Expected Result:** Status indicator updates back to Player X's turn.

## Acceptance Criteria

- The first move places X in the top-left cell and gives the turn to O.
- The second move places O in the center and returns the turn to X.
