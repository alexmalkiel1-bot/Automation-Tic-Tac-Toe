# Test Case: Verify Occupied Cell Lock

**ID:** TC-003
**Category:** Gameplay
**Priority:** P0

## Objective

Ensure players cannot overwrite an already marked cell.

## Prerequisites

- A clean game is visible.

## Test Steps

### Step 1: Reset to a clean board
- **Action:** Activate reset so the case does not depend on leftover marks.
- **Tool:** @tool:reset_game()
- **Expected Result:** An empty board is displayed.

### Step 2: Place X in the top-left cell
- **Action:** Tap Row 1, Column 1 (zero-based 0,0).
- **Tool:** @tool:tap_cell(row=0, column=0)
- **Expected Result:** Player X marks the cell with X.

### Step 3: Attempt to overwrite the same cell
- **Action:** Tap the same occupied cell again as Player O.
- **Tool:** @tool:tap_cell(row=0, column=0, expect_change=False)
- **Expected Result:** The occupied cell rejects the second tap.

### Step 4: Verify the cell is still X
- **Action:** Observe the top-left cell after the overwrite attempt.
- **Tool:** @tool:assert_cell_mark(row=0, column=0, mark="X")
- **Expected Result:** The cell remains X.

### Step 5: Verify it is still Player O's turn
- **Action:** Inspect the status indicator.
- **Tool:** @tool:assert_current_turn(mark="O")
- **Expected Result:** No state change occurs; it remains Player O's turn.

## Acceptance Criteria

- An occupied cell cannot be overwritten.
- The turn does not advance after an invalid tap.
