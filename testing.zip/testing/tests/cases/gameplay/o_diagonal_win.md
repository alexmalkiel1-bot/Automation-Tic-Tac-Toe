# Test Case: Verify Player O Victory (Diagonal Line)

**ID:** TC-005
**Category:** Gameplay
**Priority:** P0

## Objective

Validate win detection when Player O completes a diagonal line.

## Prerequisites

- A clean game is visible.

## Test Steps

### Step 1: Reset to a clean board
- **Action:** Activate reset so the case does not depend on leftover marks.
- **Tool:** @tool:reset_game()
- **Expected Result:** An empty board is displayed.

### Step 2: X marks top-center
- **Action:** Tap Row 1, Column 2 (zero-based 0,1).
- **Tool:** @tool:tap_cell(row=0, column=1)
- **Expected Result:** Player X marks the top-center cell.

### Step 3: O marks top-left
- **Action:** Tap Row 1, Column 1 (zero-based 0,0).
- **Tool:** @tool:tap_cell(row=0, column=0)
- **Expected Result:** Player O starts the diagonal.

### Step 4: X marks top-right
- **Action:** Tap Row 1, Column 3 (zero-based 0,2).
- **Tool:** @tool:tap_cell(row=0, column=2)
- **Expected Result:** Player X marks the top-right cell.

### Step 5: O marks center
- **Action:** Tap Row 2, Column 2 (zero-based 1,1).
- **Tool:** @tool:tap_cell(row=1, column=1)
- **Expected Result:** Player O marks the center of the diagonal.

### Step 6: X marks middle-left
- **Action:** Tap Row 2, Column 1 (zero-based 1,0).
- **Tool:** @tool:tap_cell(row=1, column=0)
- **Expected Result:** Player X marks a side cell.

### Step 7: O completes the diagonal
- **Action:** Tap Row 3, Column 3 (zero-based 2,2).
- **Tool:** @tool:tap_cell(row=2, column=2)
- **Expected Result:** Player O completes the diagonal.

### Step 8: Verify Player O wins
- **Action:** Observe the win announcement.
- **Tool:** @tool:assert_winner(mark="O")
- **Expected Result:** Status indicator updates to Player O Wins.

### Step 9: Attempt a move after the win
- **Action:** Tap a remaining empty cell at Row 3, Column 1 (zero-based 2,0).
- **Tool:** @tool:tap_cell(row=2, column=0, expect_change=False)
- **Expected Result:** The grid is non-interactive until restart.

### Step 10: Verify the leftover cell stayed empty
- **Action:** Observe the cell tapped after the win.
- **Tool:** @tool:assert_cell_empty(row=2, column=0)
- **Expected Result:** Cell (2,0) remains empty.

## Acceptance Criteria

- Diagonal cells (0,0), (1,1), and (2,2) display O.
- Player O is announced as the winner.
- Further empty-cell taps are ignored.
