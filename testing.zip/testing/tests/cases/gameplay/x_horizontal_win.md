# Test Case: Verify Player X Victory (Horizontal Line)

**ID:** TC-004
**Category:** Gameplay
**Priority:** P0

## Objective

Validate win detection when Player X completes a horizontal row.

## Prerequisites

- A clean game is visible.

## Test Steps

### Step 1: Reset to a clean board
- **Action:** Activate reset so the case does not depend on leftover marks.
- **Tool:** @tool:reset_game()
- **Expected Result:** An empty board is displayed.

### Step 2: X marks top-left
- **Action:** Tap Row 1, Column 1 (zero-based 0,0).
- **Tool:** @tool:tap_cell(row=0, column=0)
- **Expected Result:** Player X marks the first cell of the top row.

### Step 3: O marks middle-left
- **Action:** Tap Row 2, Column 1 (zero-based 1,0).
- **Tool:** @tool:tap_cell(row=1, column=0)
- **Expected Result:** Player O marks a blocking cell.

### Step 4: X marks top-center
- **Action:** Tap Row 1, Column 2 (zero-based 0,1).
- **Tool:** @tool:tap_cell(row=0, column=1)
- **Expected Result:** Player X marks the second cell of the top row.

### Step 5: O marks center
- **Action:** Tap Row 2, Column 2 (zero-based 1,1).
- **Tool:** @tool:tap_cell(row=1, column=1)
- **Expected Result:** Player O marks the center cell.

### Step 6: X completes the top row
- **Action:** Tap Row 1, Column 3 (zero-based 0,2).
- **Tool:** @tool:tap_cell(row=0, column=2)
- **Expected Result:** Player X completes a horizontal line.

### Step 7: Verify Player X wins
- **Action:** Observe the win announcement.
- **Tool:** @tool:assert_winner(mark="X")
- **Expected Result:** Status indicator updates to Player X Wins.

### Step 8: Attempt a move after the win
- **Action:** Tap a remaining empty cell at Row 3, Column 3 (zero-based 2,2).
- **Tool:** @tool:tap_cell(row=2, column=2, expect_change=False)
- **Expected Result:** The game locks input and the tap does nothing.

### Step 9: Verify the leftover cell stayed empty
- **Action:** Observe the cell tapped after the win.
- **Tool:** @tool:assert_cell_empty(row=2, column=2)
- **Expected Result:** Cell (2,2) remains empty.

## Acceptance Criteria

- The top row shows three X marks.
- Player X is announced as the winner.
- Further empty-cell taps are ignored.
