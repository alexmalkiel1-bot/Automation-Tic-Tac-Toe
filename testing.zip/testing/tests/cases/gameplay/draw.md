# Test Case: Verify Draw / Tie Game Scenario

**ID:** TC-006
**Category:** Gameplay
**Priority:** P0

## Objective

Validate game handling when all 9 cells are filled with no 3-in-a-row winner.

## Prerequisites

- A clean game is visible.

## Test Steps

### Step 1: Reset to a clean board
- **Action:** Activate reset so the case does not depend on leftover marks.
- **Tool:** @tool:reset_game()
- **Expected Result:** An empty board is displayed.

### Step 2: Fill the board with a draw sequence
- **Action:** Play the 1-based sequence X(1,1) O(1,2) X(1,3) O(2,3) X(2,1) O(3,1) X(2,2) O(3,3) X(3,2).
- **Tool:** @tool:play_moves(moves="0,0; 0,1; 0,2; 1,2; 1,0; 2,0; 1,1; 2,2; 2,1")
- **Expected Result:** All 9 grid positions are populated with no winner.

### Step 3: Verify the draw
- **Action:** Observe the status indicator after the board is full.
- **Tool:** @tool:assert_draw()
- **Expected Result:** Status indicator displays a draw or tie.

## Acceptance Criteria

- All 9 cells are populated.
- A draw or tie status is visible.
- No player is announced as the winner.
