# Test Case: Verify App Backgrounding & Resume Integrity

**ID:** TC-008
**Category:** Lifecycle
**Priority:** P0

## Objective

Confirm game state is preserved when sending the app to the background.

## Prerequisites

- A game is open.

## Test Steps

### Step 1: Reset to a clean board
- **Action:** Activate reset so the case does not depend on leftover marks.
- **Tool:** @tool:reset_game()
- **Expected Result:** An empty board is displayed.

### Step 2: Place X in the top-left cell
- **Action:** Tap Row 1, Column 1 (zero-based 0,0).
- **Tool:** @tool:tap_cell(row=0, column=0)
- **Expected Result:** Player X marks the top-left cell.

### Step 3: Place O in the center
- **Action:** Tap Row 2, Column 2 (zero-based 1,1).
- **Tool:** @tool:tap_cell(row=1, column=1)
- **Expected Result:** Player O marks the center cell.

### Step 4: Send the app to the background
- **Action:** Minimize the app with the Home button.
- **Tool:** @tool:background_app()
- **Expected Result:** The app leaves the foreground.

### Step 5: Resume the app
- **Action:** Re-open the app without force-stopping it.
- **Tool:** @tool:resume_app()
- **Expected Result:** The previous game screen is restored.

### Step 6: Verify X is still in the top-left cell
- **Action:** Observe cell (0,0) after resume.
- **Tool:** @tool:assert_cell_mark(row=0, column=0, mark="X")
- **Expected Result:** Cell (0,0) shows X.

### Step 7: Verify O is still in the center
- **Action:** Observe cell (1,1) after resume.
- **Tool:** @tool:assert_cell_mark(row=1, column=1, mark="O")
- **Expected Result:** Cell (1,1) shows O.

### Step 8: Verify it is still Player X's turn
- **Action:** Inspect the status indicator after resume.
- **Tool:** @tool:assert_current_turn(mark="X")
- **Expected Result:** Status indicator remains Player X's turn.

## Acceptance Criteria

- The game state is fully restored after backgrounding.
- Cell (0,0) shows X and cell (1,1) shows O.
- Player X is still to move.
