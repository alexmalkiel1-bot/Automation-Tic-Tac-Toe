from xo_automation.tools import assertions
from xo_automation.tools.ui import observe_board


XML = """<?xml version="1.0" encoding="UTF-8"?>
<hierarchy>
  <node content-desc="Player O's turn (O)" bounds="[0,0][10,10]"/>
  <node content-desc="cell 1,1 X" text="X" bounds="[407,1102][694,1389]"/>
</hierarchy>
"""


def test_assert_cell_mark_uses_observed_cell(monkeypatch):
    monkeypatch.setattr("xo_automation.tools.mobile.dump_ui_xml", lambda: XML)
    result = assertions.assert_cell_mark(1, 1, "X")
    assert result.status == "pass"
    missing = assertions.assert_cell_mark(0, 0, "X")
    assert missing.status == "fail"


def test_assert_cell_mark_fails_when_cells_are_not_exposed(monkeypatch):
    monkeypatch.setattr(
        "xo_automation.tools.mobile.dump_ui_xml",
        lambda: """<?xml version="1.0"?><hierarchy><node content-desc="Player X's turn (X)"/></hierarchy>""",
    )
    result = assertions.assert_cell_mark(1, 1, "X")
    assert result.status == "fail"
    assert "not exposed" in result.message


def test_observe_board_does_not_treat_turn_indicator_as_a_cell():
    observation = observe_board(
        """<?xml version="1.0"?><hierarchy><node content-desc="Player X's turn (X)"/></hierarchy>"""
    )
    assert observation.visible_cells == 0
    assert observation.current_turn == "X"


def test_assert_board_empty_fails_when_cells_are_not_exposed(monkeypatch):
    monkeypatch.setattr(
        "xo_automation.tools.mobile.dump_ui_xml",
        lambda: """<?xml version="1.0"?><hierarchy><node content-desc="Player X's turn (X)"/></hierarchy>""",
    )
    result = assertions.assert_board_empty()
    assert result.status == "fail"
    assert "not exposed" in result.message


def test_assert_board_empty_fails_on_invalid_xml(monkeypatch):
    monkeypatch.setattr("xo_automation.tools.mobile.dump_ui_xml", lambda: "<hierarchy><node")
    result = assertions.assert_board_empty()
    assert result.status == "fail"
    assert "invalid" in result.message.lower()


def test_assert_board_empty_passes_when_unlabeled_grid_is_empty(monkeypatch):
    origin_x, origin_y, size = 100, 800, 280
    nodes = ['<node content-desc="Player X\'s turn (X)" bounds="[0,0][400,80]"/>']
    for row in range(3):
        for column in range(3):
            left = origin_x + column * size
            top = origin_y + row * size
            nodes.append(
                f'<node clickable="true" bounds="[{left},{top}][{left + size},{top + size}]"/>'
            )
    monkeypatch.setattr(
        "xo_automation.tools.mobile.dump_ui_xml",
        lambda: f'<?xml version="1.0"?><hierarchy>{"".join(nodes)}</hierarchy>',
    )
    result = assertions.assert_board_empty()
    assert result.status == "pass"


def test_assert_board_empty_passes_when_labeled_cells_are_empty(monkeypatch):
    monkeypatch.setattr(
        "xo_automation.tools.mobile.dump_ui_xml",
        lambda: """<?xml version="1.0"?><hierarchy>
          <node content-desc="cell 0,0 empty"/>
          <node content-desc="cell 1,1 empty"/>
        </hierarchy>""",
    )
    result = assertions.assert_board_empty()
    assert result.status == "pass"


def test_assert_current_turn_reads_visible_indicator(monkeypatch):
    monkeypatch.setattr("xo_automation.tools.mobile.dump_ui_xml", lambda: XML)
    result = assertions.assert_current_turn("O")
    assert result.status == "pass"
    wrong = assertions.assert_current_turn("X")
    assert wrong.status == "fail"


def test_assert_cell_empty_uses_observed_cell(monkeypatch):
    monkeypatch.setattr("xo_automation.tools.mobile.dump_ui_xml", lambda: XML)
    occupied = assertions.assert_cell_empty(1, 1)
    assert occupied.status == "fail"
    monkeypatch.setattr(
        "xo_automation.tools.mobile.dump_ui_xml",
        lambda: """<?xml version="1.0"?><hierarchy>
          <node content-desc="cell 0,0 empty"/>
          <node content-desc="cell 1,1 X" text="X"/>
        </hierarchy>""",
    )
    result = assertions.assert_cell_empty(0, 0)
    assert result.status == "pass"
    occupied = assertions.assert_cell_empty(1, 1)
    assert occupied.status == "fail"


def test_assert_cell_empty_fails_when_cells_are_not_exposed(monkeypatch):
    monkeypatch.setattr(
        "xo_automation.tools.mobile.dump_ui_xml",
        lambda: """<?xml version="1.0"?><hierarchy><node content-desc="Player X's turn (X)"/></hierarchy>""",
    )
    result = assertions.assert_cell_empty(0, 0)
    assert result.status == "fail"
    assert "not exposed" in result.message


def test_assert_control_visible_reads_labeled_node(monkeypatch):
    monkeypatch.setattr(
        "xo_automation.tools.mobile.dump_ui_xml",
        lambda: """<?xml version="1.0"?><hierarchy>
          <node content-desc="Reset Game"/>
        </hierarchy>""",
    )
    result = assertions.assert_control_visible("Reset Game")
    assert result.status == "pass"
    missing = assertions.assert_control_visible("New Game")
    assert missing.status == "fail"


def test_assert_reset_state_requires_empty_board_and_x_turn(monkeypatch):
    monkeypatch.setattr(
        "xo_automation.tools.mobile.dump_ui_xml",
        lambda: """<?xml version="1.0"?><hierarchy>
          <node content-desc="Player X's turn (X)"/>
          <node content-desc="cell 0,0 empty"/>
        </hierarchy>""",
    )
    result = assertions.assert_reset_state()
    assert result.status == "pass"
    monkeypatch.setattr(
        "xo_automation.tools.mobile.dump_ui_xml",
        lambda: """<?xml version="1.0"?><hierarchy>
          <node content-desc="Player O's turn (O)"/>
          <node content-desc="cell 0,0 empty"/>
        </hierarchy>""",
    )
    wrong_turn = assertions.assert_reset_state()
    assert wrong_turn.status == "fail"
