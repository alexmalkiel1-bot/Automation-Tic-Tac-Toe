import pytest

from xo_automation.runtime import reset


@pytest.fixture(autouse=True)
def _reset_runtime():
    reset()
    yield
    reset()
