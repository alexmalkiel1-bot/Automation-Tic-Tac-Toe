from types import SimpleNamespace

from xo_automation.models import BoardObservation
from xo_automation.tools.game import background_app, resume_app, tap_cell
from xo_automation.tools.results import passed


def test_tap_cell_rejects_out_of_range_coordinates():
    result = tap_cell(3, 1)
    assert result.status == "fail"
    assert "0 and 2" in result.message


def test_tap_cell_fails_when_a_locked_cell_changes_state(monkeypatch):
    monkeypatch.setattr("xo_automation.tools.game.time.sleep", lambda *_: None)
    monkeypatch.setattr("xo_automation.tools.game.tap_at", lambda x, y: None)
    before = BoardObservation(board=[["X", "", ""], ["", "", ""], ["", "", ""]], current_turn="O", game_status="playing", visible_cells=9, positions_logged=1)
    after = BoardObservation(board=[["O", "", ""], ["", "", ""], ["", "", ""]], current_turn="X", game_status="playing", visible_cells=9, positions_logged=2)
    states = iter([before, after])
    monkeypatch.setattr(
        "xo_automation.tools.game.try_capture_observation",
        lambda label, screenshot=False: next(states),
    )
    monkeypatch.setattr("xo_automation.tools.game.current", lambda: None)
    result = tap_cell(0, 0, expect_change=False)
    assert result.status == "fail"
    assert "expected the tap to be ignored" in result.message


def test_tap_cell_passes_when_a_locked_cell_does_not_change(monkeypatch):
    monkeypatch.setattr("xo_automation.tools.game.time.sleep", lambda *_: None)
    monkeypatch.setattr("xo_automation.tools.game.tap_at", lambda x, y: None)
    same = BoardObservation(board=[["X", "", ""], ["", "", ""], ["", "", ""]], current_turn="O", game_status="won", visible_cells=9, positions_logged=5)
    monkeypatch.setattr(
        "xo_automation.tools.game.try_capture_observation",
        lambda label, screenshot=False: same,
    )
    monkeypatch.setattr("xo_automation.tools.game.current", lambda: None)
    result = tap_cell(2, 2, expect_change=False)
    assert result.status == "pass"
    assert "unchanged" in result.message


def test_tap_cell_fails_when_an_accepted_move_does_not_change_state(monkeypatch):
    monkeypatch.setattr("xo_automation.tools.game.time.sleep", lambda *_: None)
    monkeypatch.setattr("xo_automation.tools.game.tap_at", lambda x, y: None)
    same = BoardObservation(current_turn="X", game_status="playing", visible_cells=9, positions_logged=0)
    monkeypatch.setattr(
        "xo_automation.tools.game.try_capture_observation",
        lambda label, screenshot=False: same,
    )
    monkeypatch.setattr("xo_automation.tools.game.current", lambda: None)
    result = tap_cell(1, 1, expect_change=True)
    assert result.status == "fail"
    assert "did not change" in result.message


def test_background_app_presses_home(monkeypatch):
    calls: list[tuple] = []
    monkeypatch.setattr("xo_automation.tools.game.time.sleep", lambda *_: None)
    monkeypatch.setattr(
        "xo_automation.tools.game.adb",
        lambda *args, **kwargs: calls.append(args) or SimpleNamespace(returncode=0, stderr=""),
    )
    result = background_app()
    assert result.status == "pass"
    assert calls == [("shell", "input", "keyevent", "3")]


def test_resume_app_relaunches_without_force_stop(monkeypatch):
    launched: list[str] = []
    monkeypatch.setattr("xo_automation.tools.game.time.sleep", lambda *_: None)
    monkeypatch.setattr(
        "xo_automation.tools.game.launch_app",
        lambda package: launched.append(package) or passed(f"launched {package}"),
    )
    monkeypatch.setattr(
        "xo_automation.tools.game.try_capture_observation",
        lambda label, screenshot=False: BoardObservation(current_turn="X", visible_cells=2),
    )
    result = resume_app()
    assert result.status == "pass"
    assert launched == ["com.qatest.xo_qa_challenge"]
