from pathlib import Path

import pytest

from xo_automation.parsers.markdown_plan import parse_case, parse_plan, parse_tool_arguments


ROOT = Path(__file__).parents[2]


def test_smoke_plan_parses():
    plan = parse_plan(ROOT / "tests/plans/smoke.md")
    assert plan.plan_id == "PLAN-SMOKE-001"
    assert len(plan.prerequisites) == 2
    assert len(plan.cases) == 8
    assert Path(plan.cases[0].resolved_path).exists()
    assert [case.name.split(":")[0] for case in plan.cases] == [
        "TC-001",
        "TC-002",
        "TC-003",
        "TC-004",
        "TC-005",
        "TC-006",
        "TC-007",
        "TC-008",
    ]


def test_alternating_turns_case_parses():
    case = parse_case(ROOT / "tests/cases/gameplay/alternating_turns.md")
    assert case.case_id == "TC-002"
    assert case.steps[0].tool_name == "reset_game"
    assert case.steps[1].tool_name == "tap_cell"
    assert case.steps[1].parsed_arguments == {"row": 0, "column": 0}
    assert case.steps[2].tool_name == "assert_cell_mark"
    assert case.steps[2].parsed_arguments == {"row": 0, "column": 0, "mark": "X"}


def test_parse_tool_arguments_rejects_expressions():
    with pytest.raises(ValueError):
        parse_tool_arguments("__import__('os').system('pwd')")


def test_missing_case_file_is_rejected(tmp_path: Path):
    plan = tmp_path / "plan.md"
    plan.write_text(
        "# Test Plan: Broken\n\n**ID:** PLAN-BAD-001\n\n## 1. Prerequisites\n- [ ] @tool:setup()\n\n## 2. Test Cases\n- [ ] [TC-001: Missing](missing.md)\n",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="Case file not found"):
        parse_plan(plan)
