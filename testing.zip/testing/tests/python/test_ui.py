from types import SimpleNamespace

from xo_automation.hooks import result_failed, tool_names_from_message as hook_names
from xo_automation.tools.mobile import dump_ui_xml
from xo_automation.tools.ui import compact_ui_summary, extract_ui_xml, observe_board


SAMPLE_XML = """<?xml version="1.0" encoding="UTF-8"?>
<hierarchy>
  <node content-desc="Player X's turn (X)" text="" bounds="[0,0][100,50]"/>
  <node content-desc="cell 1,1 X" text="X" bounds="[407,1102][694,1389]" clickable="true"/>
  <node content-desc="Reset Game" text="" bounds="[20,1600][200,1680]" clickable="true"/>
</hierarchy>
"""


def test_dump_ui_xml_strips_trailer(monkeypatch):
    monkeypatch.setattr(
        "xo_automation.tools.mobile.adb",
        lambda *args, **kwargs: SimpleNamespace(
            returncode=0,
            stdout=SAMPLE_XML + "\nUI hierchary dumped to: /dev/tty\n",
            stderr="",
        ),
    )
    xml = dump_ui_xml()
    assert xml.endswith("</hierarchy>")
    assert "hierchary dumped" not in xml


def test_extract_ui_xml_strips_uiautomator_trailer():
    dump = SAMPLE_XML + "\nUI hierchary dumped to: /dev/tty\n"
    cleaned = extract_ui_xml(dump)
    assert cleaned.endswith("</hierarchy>")
    assert "hierchary dumped" not in cleaned
    observation = observe_board(dump)
    assert observation.parse_ok
    assert observation.board[1][1] == "X"


def test_observe_board_marks_unparseable_xml():
    observation = observe_board("<hierarchy><node")
    assert not observation.parse_ok
    assert observation.visible_cells == 0
    assert "invalid" in observation.summary.lower()


def _unlabeled_board_xml(marks: list[list[str]] | None = None) -> str:
    marks = marks or [["", "", ""] for _ in range(3)]
    origin_x, origin_y, size = 100, 800, 280
    nodes = ['<node content-desc="Player X\'s turn (X)" bounds="[0,0][400,80]"/>']
    for row in range(3):
        for column in range(3):
            left = origin_x + column * size
            top = origin_y + row * size
            mark = marks[row][column]
            text = f' text="{mark}"' if mark else ""
            nodes.append(
                f'<node clickable="true" bounds="[{left},{top}][{left + size},{top + size}]"{text}/>'
            )
    nodes.append('<node content-desc="Reset Game" clickable="true" bounds="[200,1700][520,1800]"/>')
    return f'<?xml version="1.0"?><hierarchy>{"".join(nodes)}</hierarchy>'


def test_observe_board_reads_unlabeled_clickable_grid():
    observation = observe_board(_unlabeled_board_xml())
    assert observation.parse_ok
    assert observation.visible_cells == 9
    assert observation.board == [["", "", ""], ["", "", ""], ["", "", ""]]
    assert observation.current_turn == "X"


def test_observe_board_reads_mark_text_on_unlabeled_grid():
    marks = [["", "", ""], ["", "X", ""], ["", "", "O"]]
    observation = observe_board(_unlabeled_board_xml(marks))
    assert observation.board[1][1] == "X"
    assert observation.board[2][2] == "O"
    assert observation.visible_cells == 9


def test_observe_board_reads_labeled_cell_and_turn():
    observation = observe_board(SAMPLE_XML)
    assert observation.current_turn == "X"
    assert observation.board[1][1] == "X"
    assert observation.visible_cells == 1
    assert observation.game_status == "playing"


def test_compact_summary_keeps_labeled_nodes():
    summary = compact_ui_summary(SAMPLE_XML)
    assert "Reset Game" in summary
    assert "cell 1,1 X" in summary


def test_hook_helpers_read_tool_uses_and_failures():
    names = hook_names({"content": [{"toolUse": {"name": "tap_cell"}}, {"toolUse": {"name": "get_board_state"}}]})
    assert names == ["tap_cell", "get_board_state"]
    assert result_failed({"status": "error", "content": []})
    assert result_failed({"status": "success", "content": [{"text": '{"status": "fail", "message": "nope"}'}]})
    assert not result_failed({"status": "success", "content": [{"text": '{"status": "pass"}'}]})
