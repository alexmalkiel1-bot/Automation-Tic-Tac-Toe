from pathlib import Path

from xo_automation.cli import build_parser, main
from xo_automation.tools.storage import init_session, record_step, save_report


def test_cli_accepts_test_plan_and_output_flags(monkeypatch):
    monkeypatch.delenv("XO_API_BASE", raising=False)
    monkeypatch.delenv("XO_MODEL_ID", raising=False)
    args = build_parser().parse_args(
        [
            "--test-plan",
            "tests/plans/smoke.md",
            "--output",
            "smoke.md",
            "--api-key",
            "sk-test",
            "--api-base",
            "https://example.test/",
            "--model-id",
            "test-model",
        ]
    )
    assert args.test_plan == "tests/plans/smoke.md"
    assert args.output == "smoke.md"
    assert args.api_key == "sk-test"
    assert args.api_base == "https://example.test/"
    assert args.model_id == "test-model"


def test_cli_dry_run_exits_zero():
    assert main(["--test-plan", "tests/plans/smoke.md", "--dry-run"]) == 0


def test_cli_live_run_requires_api_key(monkeypatch):
    monkeypatch.delenv("XO_API_KEY", raising=False)
    monkeypatch.delenv("LITELLM_API_KEY", raising=False)
    assert main(["--test-plan", "tests/plans/smoke.md"]) == 2


def test_save_report_writes_explicit_output_file(tmp_path: Path):
    report = tmp_path / "smoke.md"
    init_session("Smoke", "tests/plans/smoke.md", str(tmp_path / "runs"), report_file=str(report))
    record_step(
        step_number=1,
        description="Tap cell",
        expected_result="X visible",
        actual_result="X visible",
        status="pass",
    )
    result = save_report("Wrote requested file")
    assert report.exists()
    assert "Wrote requested file" in report.read_text()
    assert result.data["path"] == str(report)
