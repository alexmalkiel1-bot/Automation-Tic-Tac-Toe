from pathlib import Path

from xo_automation.models import BoardObservation
from xo_automation.parsers.markdown_plan import parse_case, parse_tool_reference
from xo_automation.runtime import current
from xo_automation.step_runner import execute_task, invoke_named_tool
from xo_automation.tools.results import failed, passed
from xo_automation.tools.task_manager import init_test_plan


ROOT = Path(__file__).parents[2]


def test_parse_tool_reference_reads_name_and_args():
    name, arguments = parse_tool_reference('@tool:tap_cell(row=0, column=0)')
    assert name == "tap_cell"
    assert arguments == {"row": 0, "column": 0}


def test_occupied_cell_lock_has_five_prescribed_steps():
    case = parse_case(ROOT / "tests/cases/gameplay/occupied_cell_lock.md")
    assert [step.number for step in case.steps] == [1, 2, 3, 4, 5]
    assert case.steps[2].tool_name == "tap_cell"
    assert case.steps[3].tool_name == "assert_cell_mark"
    assert case.steps[4].tool_name == "assert_current_turn"


def test_execute_task_records_every_prescribed_step(tmp_path: Path, monkeypatch):
    case = tmp_path / "case.md"
    case.write_text(
        """# Test Case: Occupied

**ID:** TC-003

## Test Steps

### Step 1: Reset
- **Action:** Reset.
- **Tool:** @tool:reset_game()
- **Expected Result:** Empty board.

### Step 2: Place X
- **Action:** Tap.
- **Tool:** @tool:tap_cell(row=0, column=0)
- **Expected Result:** X is placed.

### Step 3: Overwrite
- **Action:** Tap again.
- **Tool:** @tool:tap_cell(row=0, column=0)
- **Expected Result:** Rejected.

### Step 4: Still X
- **Action:** Assert mark.
- **Tool:** @tool:assert_cell_mark(row=0, column=0, mark="X")
- **Expected Result:** Still X.

### Step 5: Still O turn
- **Action:** Assert turn.
- **Tool:** @tool:assert_current_turn(mark="O")
- **Expected Result:** Still O.
""",
        encoding="utf-8",
    )
    plan = tmp_path / "plan.md"
    plan.write_text(
        f"""# Test Plan: Test

**ID:** PLAN-TEST-001

## 1. Prerequisites
- [x] @tool:check_device_connection()

## 2. Test Cases
- [ ] [TC-003: Occupied]({case.name})

## Execution Summary
""",
        encoding="utf-8",
    )
    calls: list[str] = []
    monkeypatch.setattr(
        "xo_automation.step_runner.try_capture_observation",
        lambda label="observe": BoardObservation(current_turn="O", visible_cells=1),
    )
    from xo_automation import step_runner

    monkeypatch.setitem(step_runner.STEP_REGISTRY, "reset_game", lambda: calls.append("reset") or passed("reset"))
    monkeypatch.setitem(
        step_runner.STEP_REGISTRY,
        "tap_cell",
        lambda row, column, expect_change=True: calls.append(f"tap:{row},{column}") or passed(f"tapped {row},{column}"),
    )
    monkeypatch.setitem(
        step_runner.STEP_REGISTRY,
        "assert_cell_mark",
        lambda row, column, mark: calls.append(f"mark:{mark}") or passed("still X"),
    )
    monkeypatch.setitem(
        step_runner.STEP_REGISTRY,
        "assert_current_turn",
        lambda mark: calls.append(f"turn:{mark}") or passed("still O"),
    )
    init_test_plan(str(plan))
    task = {
        "name": "TC-003: Occupied",
        "type": "test_case",
        "ref": case.name,
        "resolved_path": str(case),
        "status": "pending",
    }
    current().current_task_name = task["name"]
    status = execute_task(task)
    assert status == "completed"
    assert calls == ["reset", "tap:0,0", "tap:0,0", "mark:X", "turn:O"]
    recorded = [step.step_number for step in current().report.test_steps if step.task_name == task["name"]]
    assert recorded == [1, 2, 3, 4, 5]


def test_execute_task_continues_after_a_failed_step(tmp_path: Path, monkeypatch):
    from xo_automation import step_runner

    case = tmp_path / "case.md"
    case.write_text(
        """# Test Case: Fail Continue

**ID:** TC-009

## Test Steps

### Step 1: First
- **Action:** First.
- **Tool:** @tool:assert_board_empty()
- **Expected Result:** Empty.

### Step 2: Second
- **Action:** Second.
- **Tool:** @tool:assert_current_turn(mark="X")
- **Expected Result:** X to move.
""",
        encoding="utf-8",
    )
    plan = tmp_path / "plan.md"
    plan.write_text(
        f"""# Test Plan: Test

**ID:** PLAN-TEST-001

## 1. Prerequisites
- [x] @tool:check_device_connection()

## 2. Test Cases
- [ ] [TC-009: Fail Continue]({case.name})

## Execution Summary
""",
        encoding="utf-8",
    )
    monkeypatch.setitem(step_runner.STEP_REGISTRY, "assert_board_empty", lambda: failed("not empty"))
    monkeypatch.setitem(step_runner.STEP_REGISTRY, "assert_current_turn", lambda mark: passed(f"turn {mark}"))
    init_test_plan(str(plan))
    task = {
        "name": "TC-009: Fail Continue",
        "type": "test_case",
        "ref": case.name,
        "resolved_path": str(case),
        "status": "pending",
    }
    current().current_task_name = task["name"]
    status = execute_task(task)
    assert status == "failed"
    steps = [step for step in current().report.test_steps if step.task_name == task["name"]]
    assert [step.step_number for step in steps] == [1, 2]
    assert steps[0].status == "fail"
    assert steps[1].status == "pass"


def test_invoke_unknown_tool_fails():
    result = invoke_named_tool("not_a_tool")
    assert result.status == "fail"
