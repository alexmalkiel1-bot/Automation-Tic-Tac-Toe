from pathlib import Path

from xo_automation.tools.storage import init_session, record_step, save_report


def test_markdown_report_is_written(tmp_path: Path):
    output_dir = init_session("Smoke", "tests/plans/smoke.md", str(tmp_path))
    recorded = record_step(
        step_number=1,
        description="Tap cell",
        expected_result="X visible",
        actual_result="X visible",
        status="pass",
        task_name="TC-001: Verify Initial App Launch & Default UI State",
    )
    assert recorded.status == "pass"
    result = save_report("One step passed")
    report = output_dir / "overall.md"
    assert report.exists()
    text = report.read_text()
    assert "## Test Steps" in text
    assert "### TC-001: Verify Initial App Launch & Default UI State" in text
    assert "One step passed" in text
    assert result.status == "pass"


def test_record_step_keeps_same_step_number_across_cases(tmp_path: Path):
    output_dir = init_session("Smoke", "tests/plans/smoke.md", str(tmp_path))
    first = record_step(
        step_number=1,
        description="Inspect launch UI",
        expected_result="Empty board",
        actual_result="Empty board",
        status="pass",
        task_name="TC-001: Verify Initial App Launch & Default UI State",
    )
    second = record_step(
        step_number=1,
        description="Reset to a clean board",
        expected_result="Empty board",
        actual_result="Empty board",
        status="fail",
        task_name="TC-007: Verify Reset / Restart Functionality",
    )
    assert first.status == "pass"
    assert second.status == "pass"
    save_report("Two cases recorded")
    text = (output_dir / "overall.md").read_text()
    assert "### TC-001: Verify Initial App Launch & Default UI State" in text
    assert "### TC-007: Verify Reset / Restart Functionality" in text
    assert "Inspect launch UI" in text
    assert "Reset to a clean board" in text
    assert text.index("TC-001") < text.index("TC-007")
